###########################################
## MLE estimation via Newton-Raphson/ILRS
###########################################
##
logistic_NR <- function(X, # design matrix 
                        y, # response
                        tol = 1e-8, # tolerance for convergence
                        maxit = 100, # maximum number of iterations
                        report = 1 # number of outputs displayed
                        ){
  
  n <- nrow(X)
  p <- ncol(X)
  
  beta <- rep(0, p)
  
  for(it in 1:maxit){
    eta <- X %*% beta
    p_hat <- 1/(1 + exp(-eta))
    W <- as.vector(p_hat*(1-p_hat))
    score <- t(X) %*% (y - p_hat)
    Hessian <- -t(X) %*% (W * X)
    beta_new <- beta - solve(Hessian, score)
    
    if(it %% report == 0) cat(paste0("\tit: ", it, "\terr: ", max(abs(beta_new-beta)), "\n"))
    
    if(max(abs(beta_new-beta)) < tol){
      beta <- beta_new
      break
    }
    
    beta <- beta_new
  }
  
  eta <- X %*% beta
  
  p_hat <- 1/(1+exp(-eta))
  
  logLik <- sum(
    y*log(p_hat) +
      (1-y)*log(1-p_hat)
  )
  
  list(coefficients = beta,
       logLik = logLik,
       iterations = it
  )
}

###########################################
## Bayesian Information Criterion (BIC)
###########################################
##
BIC_logistic <- function(logLik, # log-likelihood value
                         k, # number of parameters
                         n){ # sample size
  -2*logLik + k*log(n)
}

##############################
## Soft-thresholding operator
##############################
##
soft <- function(z, lambda){
  sign(z) * pmax(abs(z) - lambda, 0)
}

##############################
## L1-penalised MLE via Lasso
##############################
##
logistic_lasso <- function(X, # design matrix
                           y, # response
                           lambda, # penalty weight lambda
                           tol = 1e-6, # tolerance for convergence
                           maxit = 100, # maximum number of iterations
                           report = 1, # number of output displayed
                           beta = rep(0,ncol(X))){ # starting parameters
  n <- nrow(X)
  p <- ncol(X)
  # beta <- rep(0,p)
  
  for(it in 1:maxit){
    beta_old <- beta
    eta <- X %*% beta
    p_hat <- 1/(1 + exp(-eta))
    w <- as.vector(p_hat*(1-p_hat))
    z <- eta + (y-p_hat)/w
    
    # update intercept
    r <- z - X[, -1, drop=FALSE] %*% beta[-1]
    beta[1] <- sum(w*r)/sum(w)
    
    # update coefficients
    for(j in 2:p){
      r_j <- (z - X[,1,drop=FALSE]*beta[1] 
              - X[,-c(1,j),drop=FALSE] %*% beta[-c(1,j)])
      aj <- sum(w*X[,j]^2)
      cj <- sum(w*X[,j]*r_j)
      
      beta[j] <- soft(cj, lambda)/aj
    }
    
    if(it %% report == 0) cat(paste0("\tit: ", it, "\terr: ", max(abs(beta-beta_old)), "\n"))
    if(max(abs(beta-beta_old)) < tol) break
  }
  
  list(coefficients = beta,
       iterations = it)
}

##################
## Folds Builder
##################
##
# Description: It separates the observations according to their outcome class, 
# namely stroke ($y=1$) and non-stroke ($y=0$). 
# Within each class, observations are randomly assigned to one of the $K$ folds. 
# The assignments from both classes are then combined to obtain the final 
# fold membership vector.
make_folds <- function(y, K = 10){
  folds <- integer(length(y))
  idx0 <- which(y == 0)
  idx1 <- which(y == 1)
  folds[idx0] <- sample(rep(1:K, length.out = length(idx0)))
  folds[idx1] <- sample(rep(1:K, length.out = length(idx1)))
  folds
}

###############################################
## Lambda selection based on cross validation
###############################################
##
cv_logistic_lasso <- function(X, # design matrix
                              y, # response
                              lambda_grid, # candidate lambda values
                              K = 10, # number of folds
                              seed = 123, # random seed generator
                              tol = 1e-6, # tolerance for convergence
                              maxit = 100, # maximum number of iterations
                              report = 1, # number of outputs displayed
                              beta = rep(0,ncol(X))){ # starting parameters
  
  set.seed(seed)
  n <- nrow(X)
  folds <- make_folds(y, K)
  M <- length(lambda_grid)
  cv_loss <- numeric(M)
  
  for(k in 1:K){
    
    test_idx <- which(folds == k)
    train_idx <- setdiff(seq_len(n),test_idx)
    X_train <- X[train_idx, , drop = FALSE]
    y_train <- y[train_idx]
    X_test <- X[test_idx, , drop = FALSE]
    y_test <- y[test_idx]
    
    ## warm start for this fold only
    beta0 <- beta # rep(0, ncol(X))
    
    for(m in seq_along(lambda_grid)){
      
      lambda <- lambda_grid[m]
      fit <- logistic_lasso(X = X_train,
                            y = y_train,
                            lambda = lambda,
                            tol = tol,
                            maxit = maxit,
                            beta = beta0,
                            report = report)
      
      beta_hat <- fit$coefficients
      eta_test <- X_test %*% beta_hat
      p_test <- 1/(1 + exp(-eta_test))
      # eps <- 1e-12
      # p_test <- pmin(pmax(p_test, eps), 1 - eps)
      
      fold_loss <- -sum(y_test*log(p_test) + (1-y_test)*log(1-p_test))
      cv_loss[m] <- cv_loss[m] + fold_loss
      
      ## warm start for next lambda
      beta0 <- as.numeric(beta_hat)
    }
    
    cat("Completed fold", k, "of", K, "\n")
  }
  
  cv_loss <- cv_loss/K
  
  for(m in seq_along(lambda_grid)){
    cat("lambda =", lambda_grid[m],
        "CV =", cv_loss[m], "\n")
  }
  
  best <- which.min(cv_loss)
  
  list(lambda_star = lambda_grid[best],
       cv_loss = cv_loss,
       lambda_grid = lambda_grid)
}

#######################################
## Nested cross validation for ROC/AUC
#######################################
##
get.ROC_AUC <- function(K.outer = 10, # number of outer folds
                        K.inner = 10, # number of inner folds
                        dat, # dataset
                        all_models, # list of candidate models
                        lambda_grid, # lambda values for Lasso regression
                        seed = 123 # random seed generator
                        ){
  set.seed(seed)
  
  outer_folds <- make_folds(dat$stroke, K = K.outer)
  
  pred_cv_mavg  <- rep(NA, nrow(dat))
  pred_cv_lasso <- rep(NA, nrow(dat))
  
  for(k in 1:K.outer){
    
    cat("Outer fold",k,"of",K.outer,"\n")
    
    test_idx  <- which(outer_folds == k)
    train_idx <- setdiff(seq_len(nrow(dat)), test_idx)
    
    train <- dat[train_idx, ]
    test  <- dat[test_idx, ]
    
    #####################
    ## MODEL AVERAGING
    #####################
    cat("Performing Bayesian model averaging...\n")
    
    results_train <- list()
    
    for(i in seq_along(all_models)){
      
      form <- as.formula( paste("stroke ~",
                                paste(all_models[[i]], collapse="+")))
      Xtrain <- model.matrix(form, data=train)
      
      mu <- apply(Xtrain[,-1,drop=FALSE],2,mean)
      sd <- apply(Xtrain[,-1,drop=FALSE],2,sd)
      
      Xtrain[,-1] <- scale(Xtrain[,-1],
                           center=mu,
                           scale=sd)
      
      ytrain <- train$stroke
      
      fit <- logistic_NR(X = Xtrain, 
                         y = ytrain,
                         report = 1000)
      bic <- BIC_logistic(fit$logLik,
                          ncol(Xtrain),
                          nrow(Xtrain))
      
      results_train[[i]] <- list(vars = all_models[[i]],
                                 beta = fit$coefficients,
                                 bic  = bic,
                                 mean = mu,
                                 sd   = sd)
    }
    
    bics <- sapply(results_train,function(x)x$bic)
    w <- exp(-0.5*(bics-min(bics)))
    w <- w/sum(w)
    pred_models <- matrix(NA,
                          nrow=length(results_train),
                          ncol=nrow(test))
    
    for(i in seq_along(results_train)){
      
      vars <- results_train[[i]]$vars
      form <- as.formula(paste("~",paste(vars,collapse="+")))
      Xtest <- model.matrix(form,data=test)
      Xtest[,-1] <- scale(Xtest[,-1],
                          center=results_train[[i]]$mean,
                          scale=results_train[[i]]$sd)
      eta <- Xtest %*% results_train[[i]]$beta
      pred_models[i,] <- 1/(1+exp(-eta))
    }
    
    pred_cv_mavg[test_idx] <- colSums(w*pred_models)
    
    ########################
    ## LASSO (nested CV)
    ########################
    cat("Performing Lasso...\n")
    
    Xtrain <- model.matrix(stroke ~ age +
                             gender +
                             bmi +
                             avg_glucose_level +
                             hypertension +
                             heart_disease +
                             smoking_status,
                           data=train)
    
    mu <- apply(Xtrain[,-1],2,mean)
    sd <- apply(Xtrain[,-1],2,sd)
    
    Xtrain[,-1] <- scale(Xtrain[,-1],
                         center=mu,
                         scale=sd)
    
    ytrain <- train$stroke
    
    mle <- logistic_NR(X = Xtrain,
                       y = ytrain,
                       report = 1000)
    
    cv_inner <- cv_logistic_lasso(X=Xtrain,
                                  y=ytrain,
                                  lambda_grid=lambda_grid,
                                  K=K.inner,
                                  seed=seed,
                                  beta=as.numeric(mle$coefficients),
                                  report=1000)
    
    fit <- logistic_lasso(X=Xtrain,
                          y=ytrain,
                          lambda=cv_inner$lambda_star,
                          beta=as.numeric(mle$coefficients),
                          report=1000)
    
    Xtest <- model.matrix(stroke ~ age +
                            gender +
                            bmi +
                            avg_glucose_level +
                            hypertension +
                            heart_disease +
                            smoking_status,
                          data=test)
    
    Xtest[,-1] <- scale(Xtest[,-1],
                        center=mu,
                        scale=sd)
    
    eta <- Xtest %*% fit$coefficients
    
    pred_cv_lasso[test_idx] <- 1/(1+exp(-eta))
    
  }
  
  ## Cross-validated ROC curves
  roc_mavg_cv <- roc(response = dat$stroke,
                     predictor = pred_cv_mavg,
                     quiet=TRUE)
  roc_lasso_cv <- roc(response = dat$stroke,
                      predictor = pred_cv_lasso,
                      quiet=TRUE)
  
  auc_mavg_cv  <- auc(roc_mavg_cv)
  auc_lasso_cv <- auc(roc_lasso_cv)
  
  res <- list()
  res$roc_mavg_cv <- roc_mavg_cv
  res$roc_lasso_cv <- roc_lasso_cv
  res$auc_mavg_cv <- auc_mavg_cv
  res$auc_lasso_cv <- auc_lasso_cv
  
  return(res)
}

