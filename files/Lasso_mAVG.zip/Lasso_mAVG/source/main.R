
library(pROC)

source("./source/fun.R")

##############
## currTime ##
##############

currTime <- Sys.time()
currTime <- gsub(" ", "_", currTime)
currTime <- gsub("-", "", currTime)
currTime <- gsub(":", "", currTime)
currTime <- paste(currTime, sep = "_")

#############
## folders ##
#############

currDir <- getwd()
setwd(currDir)

#############
## folders ##
#############

resPath <- paste("./results", sep = "")
ifelse(!dir.exists(file.path(resPath)), dir.create(file.path(resPath)), FALSE)
resPath <- paste0(paste(resPath, currTime, sep = "/"), "/")
figPath <- paste0(resPath, "figures/")

ifelse(!dir.exists(file.path(resPath)), dir.create(file.path(resPath)), FALSE)
ifelse(!dir.exists(file.path(figPath)), dir.create(file.path(figPath)), FALSE)

## load data

dat <- read.csv(file = "./data/healthcare-dataset-stroke-data.csv")
dat <- dat[which(dat$bmi != "N/A"),]
dat <- dat[which(dat$gender != "Other"),]
dat$bmi <- as.numeric(dat$bmi)

# X <- model.matrix(stroke ~ age + bmi + hypertension, data = dat)
# y <- dat$stroke
# X[,-1] <- scale(X[,-1])
# fit <- logistic_NR(X,y)
# fit$coefficients
# 
# # glm(stroke ~ age + bmi + hypertension,
# #     family = binomial,
# #     data = dat)

#########################################
## BIC-based frequentist model averaging
#########################################

# Generate candidate models:
vars <- c("age",
          "gender",
          "bmi",
          "avg_glucose_level",
          "hypertension",
          "heart_disease",
          "smoking_status")

# Create all subsets of predictors:
all_models <- list()
counter <- 1
for(m in 1:length(vars)){
  cmb <- combn(vars,m,simplify=FALSE)
  for(j in seq_along(cmb)){
    all_models[[counter]] <- cmb[[j]]
    counter <- counter + 1
  }
}


# Fit each candidate model using Newton-Raphson/ILRS:
results <- list()
for(i in seq_along(all_models)){
  form <- as.formula(paste("stroke ~",
                           paste(all_models[[i]],
                                 collapse = "+")))
  
  X <- model.matrix(form,data=dat)
  X[,-1] <- scale(X[,-1])
  y <- dat$stroke
  fit <- logistic_NR(X,y)
  
  bic <- BIC_logistic(fit$logLik,
                      ncol(X),
                      nrow(X))
  
  results[[i]] <- list(vars = all_models[[i]],
                       beta = fit$coefficients,
                       bic = bic)
}

# Compute BIC-based model weights:
bics <- sapply(results, function(x) x$bic)
bic_min <- min(bics)
weights <- exp(-0.5*(bics-bic_min))
weights <- weights/sum(weights)

# Compute prediction under each model:
preds <- matrix(data = NA,
                nrow = length(results),
                ncol = nrow(dat))
for(i in seq_along(results)){
  vars <- results[[i]]$vars
  form <- as.formula(paste("~", paste(vars, collapse="+")))
  Xnew <- model.matrix(form,
                       data=dat)
  Xnew[,-1] <- scale(Xnew[,-1])
  
  beta <- results[[i]]$beta
  eta <- Xnew %*% beta
  preds[i,] <- 1/(1+exp(-eta))
}
p_avg <- colSums(weights*preds)

# Compute score of averaged model:
mavg_score <- sum((dat$stroke - p_avg)^2)/nrow(dat)

####################
## LASSO fit
####################

# Define full model
X <- model.matrix(
  stroke ~ age + gender + bmi + avg_glucose_level + hypertension + heart_disease + smoking_status,
  data = dat)
X[,-1] <- scale(X[,-1])

# Fit full model to data (MLE) using Newton-Raphson/ILRS: 
NR_fit <- logistic_NR(X,y)

# Define grid of lambda values for Lasso regression:
lambda_grid <- seq(0.001, 10, length.out = 100)
# Perform cross validation for selecting lambda for Lasso regression
cv_lasso.res <- cv_logistic_lasso(X = X,
                                  y = dat$stroke,
                                  lambda_grid,
                                  K = 10,
                                  seed = 123,
                                  tol = 1e-6,
                                  maxit = 100,
                                  beta = as.numeric(NR_fit$coefficients),
                                  report = 10)

pdf(file = paste0(figPath, "lasso_cv.pdf"), width = 7, height = 4)
par(mar = c(4,4.5,.5,.5))
plot(cbind(cv_lasso.res$lambda_grid, cv_lasso.res$cv_loss), 
     type = 'l', 
     lwd = 3,
     cex.axis = 2,
     cex.lab = 2,
     xlab = expression(lambda),
     ylab = "loss")
par(xpd = TRUE)
points(cv_lasso.res$lambda_star,
       cv_lasso.res$cv_loss[which(cv_lasso.res$lambda_grid == cv_lasso.res$lambda_star)],
       pch = "*",
       cex = 5,
       col = "blue")
dev.off()

# Perform Lasso regression with the best lambda
fit_lasso <- logistic_lasso(X = X,
                            y = dat$stroke,
                            lambda = cv_lasso.res$lambda_star,
                            beta = as.numeric(NR_fit$coefficients),
                            report = 1)

# Compute score of Lasso regression model:
beta_lasso <- fit_lasso$coefficients
eta_lasso <- X %*% beta_lasso
preds_lasso <- as.numeric(1/(1+exp(-eta_lasso)))
lasso_score <- sum((dat$stroke - preds_lasso)^2)/nrow(dat)

# Perform nested cross validation for ROC/AUC:
res.ROC <- get.ROC_AUC(K.outer = 10, # number of outer folds
                       K.inner = 10, # number of inner folds
                       dat = dat, # dataset
                       all_models = all_models, # list of candidate models
                       lambda_grid = lambda_grid) # random seed generator

# plotting
plot(res.ROC$roc_mavg_cv, col = scales:::alpha("black", .5), lwd = 3)
lines(res.ROC$roc_lasso_cv, col = scales:::alpha("red", .5), lwd = 3)

