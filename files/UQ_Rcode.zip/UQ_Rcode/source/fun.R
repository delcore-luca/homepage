get.logit <- function(x){
  return(log(x/(1-x)))
}

get.logistic <- function(x){
  return(exp(x)/(1 + exp(x)))
}

ll <- function(t,
               X,
               beta0, 
               beta1, 
               sigma2){
  mu <- beta0 + beta1 * t
  return(as.numeric(-0.5*n*log(2*pi*sigma2) - 0.5*sum((Y - mu)^2)/sigma2))
}

get.CI.FIM <- function(X,
                       s2,
                       beta,
                       alpha = 0.05){
  FIM <- (t(X) %*% X)/s2
  cov_beta <- solve(FIM)
  se_beta <- sqrt(diag(cov_beta))
  names(se_beta) <- names(beta)

  z_crit <- qnorm(1 - alpha/2)
  CI_FIM <- cbind(beta - z_crit * se_beta,
                  beta + z_crit * se_beta)
  rownames(CI_FIM) <- c("beta0", "beta1")
  colnames(CI_FIM) <- c("lower", "upper")
  
  xyFIM.par <- sapply(1:ncol(X), function(j){
    betaj_vals <- seq(CI_FIM[j, "lower"] - abs(CI_FIM[j, "lower"])/10, 
                      CI_FIM[j, "upper"] + abs(CI_FIM[j, "lower"])/10, 
                      length.out = 1000)
    FIM_par_j <- (-0.5 * (solve(FIM)[j,j])^-1 * (betaj_vals - beta[j])^2)
    
    return(cbind(betaj_vals, FIM_par_j))
  }, simplify = "array")
  
  xyFIM.par.res <- sapply(1:ncol(X), function(j){
    betaj_vals <- seq(CI_FIM[j, "lower"] - abs(CI_FIM[j, "lower"])/10, 
                      CI_FIM[j, "upper"] + abs(CI_FIM[j, "lower"])/10, 
                      length.out = 1000)
    FIM_par_j <- (-0.5 * (solve(FIM)[j,j])^-1 * (betaj_vals - beta[j])^2)
    
    FIM_par_j <- FIM_par_j - max(FIM_par_j)
    
    return(cbind(betaj_vals, FIM_par_j))
  }, simplify = "array")
  
  
  return(list(FIM = FIM,
              CI_FIM = CI_FIM,
              xyFIM.par = xyFIM.par,
              xyFIM.par.res = xyFIM.par.res,
              cov_beta = cov_beta,
              se_beta = se_beta))
}

PL_CI <- function(param = c("beta0", "beta1"),
                  beta_hat,
                  sigma2_hat,
                  se_beta,
                  grid_points = 1000,
                  t,
                  X,
                  Y){
  
  grid <- seq(beta_hat[param] - 3*se_beta[param],
              beta_hat[param] + 3*se_beta[param],
              length.out = grid_points)
  
  I_vec <- rep(1, length(Y))
  x <- t
  n <- length(Y)
  
  if (param == "beta0") {
    # maximize over beta1 given beta0
    PL <- sapply(grid, function(b0){
      
      y0 <- Y - b0*I_vec
      beta1_0 <- as.numeric(solve(t(x) %*% x) %*% t(x) %*% y0)
      sigma2_1_0 <- t(y0 - beta1_0*x) %*% (y0 - beta1_0*x)/(n - 1)
      
      return(ll(t = t,
                X = X,
                beta0 = b0, 
                beta1 = beta1_0, 
                sigma2 = sigma2_1_0))
    })
  } else {
    # maximize over beta0 given beta1
    PL <- sapply(grid, function(b1){
      y0 <- Y - b1*x
      beta0_1 <- as.numeric(solve(t(I_vec) %*% I_vec) %*% t(I_vec) %*% y0)
      sigma2_0_1 <- t(y0 - beta0_1*I_vec) %*% (y0 - beta0_1*I_vec)/(n - 1)
      
      return(ll(t = t,
                X = X,
                beta0 = beta0_1, 
                beta1 = b1, 
                sigma2 = sigma2_0_1))
    })
  }
  # Find cutoff for 95% CI (Chi-square(1))
  max.ll <- ll(t = t,
               X = X,
               beta0 = beta_hat["beta0"], 
               beta1 = beta_hat["beta1"], 
               sigma2 = sigma2_hat)
  cutoff <- max.ll - 0.5*qchisq(0.95, df = 1)
  inside <- which(PL > cutoff)
  CI <- c(min(grid[inside]), max(grid[inside]))
  
  
  PLres <- PL - max(PL)
  cutoff.res <- cutoff - max(PL)
  
  
  pl.res <- list(grid = grid,
                 pl = PL,
                 thr = cutoff,
                 plres = PLres,
                 thrres = cutoff.res,
                 CI = CI)
  
  return(pl.res)
}


# Function to compute prediction bounds given t*
PI_PL <- function(X,
                  t_star,
                  beta_hat,
                  sigma2_hat,
                  grid.length = 20,
                  alpha = 0.05){
  
  # Construct the set of plausible (beta0, beta1) combinations
  beta0_range <- seq(CI_PL["beta0", "lower"], 
                     CI_PL["beta0", "upper"], 
                     length.out = grid.length)
  beta1_range <- seq(CI_PL["beta1", "lower"], 
                     CI_PL["beta1", "upper"], 
                     length.out = grid.length)
  
  # Generate all combinations of (beta0, beta1) from their profile CIs
  param_grid <- expand.grid(beta0 = beta0_range, 
                            beta1 = beta1_range)
  
  y_pred_vals <- param_grid$beta0 + param_grid$beta1 * t_star
  y_pred_hat <- as.numeric(X %*% beta_hat) # mean prediction using OLS
  z_crit <- qnorm(1 - alpha / 2)
  
  # Prediction bounds considering both parameter range and residual noise
  lower <- min(y_pred_vals) - z_crit * sqrt(sigma2_hat)
  upper <- max(y_pred_vals) + z_crit * sqrt(sigma2_hat)
  
  c(lower, upper)
}


get.PI_FIM <- function(I_hat_i,
                   sigma2_hat,
                   alpha,
                   beta_hat,
                   t0,
                   Y,
                   MEAN = FALSE){
  
  if(MEAN){
    offset <- 0
  }else{
    offset <- 1
  }
  
  x0 <- c(1,t0)
  y0_hat <-  x0 %*% beta_hat
  k <- length(beta_hat)
  n <- length(Y)
  
  bound <- qt(p = 1 - alpha/2,
                          df = n - k)*sqrt(sigma2_hat)*sqrt(offset + t(x0) %*% I_hat_i %*% x0)
  
  pi_fim <- c(y0_hat - bound,
              y0_hat + bound)
  return(pi_fim)
}


get.JKP <- function(x,
                    X, 
                    Y, 
                    alpha = 0.05) {
  n <- nrow(X)
  residuals <- rep(NA, n)
  y_pred_x <- rep(NA, n)
  for (i in 1:n) {
    X_i <- X[-i, ]
    Y_i <- Y[-i]
    beta_i <- solve(t(X_i) %*% X_i) %*% t(X_i) %*% Y_i
    y_pred_i <- as.vector(X[i, ] %*% beta_i)
    y_pred_x[i] <- cbind(1, x) %*% beta_i
    residuals[i] <- abs(Y[i] - y_pred_i)
  }
  
  # I_low <- apply(cbind(Y, y_pred_x), 1, min) - residuals
  # I_up <- apply(cbind(Y, y_pred_x), 1, max) + residuals
  # 
  # C_JKP_x <- c(quantile(I_low, probs = alpha),
  #              quantile(I_up, probs = 1 - alpha))
  
  I_low <- y_pred_x - residuals
  I_up <- y_pred_x + residuals
  C_JKP_x <- c(quantile(I_low, probs = alpha/2),
              quantile(I_up, probs = 1 - alpha/2))
  
  
  return(C_JKP_x)
}


get.MCMC <- function(X,
                     Y,
                     V0,
                     a0,
                     b0,
                     n_iter,
                     beta0,
                     s20){
  
  V0i <- solve(V0)
  n <- length(Y)
  
  beta_samples <- matrix(0, n_iter, 2)
  sigma2_samples <- numeric(n_iter)
  
  # Initial values
  beta_curr <- beta0
  sigma2_curr <- s20
  
  for (i in 1:n_iter) {
    # Sample beta | sigma2, Y
    Vp <- solve(t(X) %*% X/sigma2_curr + V0i)
    mup <- Vp %*% (t(X) %*% Y/sigma2_curr)
    beta_curr <- as.vector(mvtnorm::rmvnorm(1, mup, Vp))
    
    # Sample sigma2 | beta, Y
    ap <- a0 + n/2
    bp <- b0 + sum((Y - X %*% beta_curr)^2)/2
    sigma2_curr <- 1/rgamma(1, shape = ap, rate = bp)
    
    beta_samples[i, ] <- beta_curr
    sigma2_samples[i] <- sigma2_curr
  }
  
  return(list(beta_samples = beta_samples,
              sigma2_samples = sigma2_samples))
}

get.PI_Bayes <- function(beta_post,
                         sigma2_post,
                         Y){
  # Posterior predictive draws for each observation
  Y_pred_post <- matrix(NA, nrow = length(Y), ncol = nrow(beta_post))
  
  for (m in 1:nrow(beta_post)) {
    mu_m <- X %*% beta_post[m, ]
    Y_pred_post[, m] <- rnorm(n, mean = mu_m, sd = sqrt(sigma2_post[m]))
  }
  
  # Compute pointwise 95% credible intervals for predicted Y
  PI_bayes <- t(apply(Y_pred_post, 1, quantile, probs = c(0.025, 0.975)))
  colnames(PI_bayes) <- c("lower", "upper")
  
  return(PI_bayes)
}
