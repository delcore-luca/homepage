
## install/load packages
# install.packages("mvtnorm")
library(mvtnorm)

## load functions
source("./source/fun.R")

####################
## create folders ##
####################

resPath <- paste("./results/", sep = "")
ifelse(!dir.exists(file.path(resPath)), 
       dir.create(file.path(resPath)), FALSE)
figPath <- paste0(resPath, "figures/")
ifelse(!dir.exists(file.path(figPath)), 
       dir.create(file.path(figPath)), FALSE)

########################################
## Simulate Data from the true model
set.seed(123)

# True parameters
beta0_true <- get.logit(.0005)
beta1_true <- .3
sigma_true <- .1


# Simulate predictor and response
n <- 100
t <- seq(0, 50, length.out = n)
epsilon <- rnorm(n, mean = 0, sd = sigma_true)
Y <- beta0_true + beta1_true * t + epsilon


pdf(file = paste0(figPath, "sim-data.pdf"), width = 10, height = 5)
par(mar = c(4,5.5,1,1))
plot(x = t,
     y = get.logistic(Y),
     pch = 20,
     xlab = "t",
     ylab = expression(e^y/(1 + e^y)),
     cex.axis = 2,
     cex.lab = 2)
dev.off()

#####################
## OLS ESTIMATES

# Build design matrix
X <- cbind(1, t)

# OLS estimator: (X'X)^(-1) X'Y
beta_hat <- solve(t(X) %*% X) %*% t(X) %*% Y
beta_hat <- as.vector(beta_hat)
names(beta_hat) <- c("beta0", "beta1")

# Residuals and estimated variance
residuals <- Y - X %*% beta_hat
dfr <- n - 2 # degrees of freedom
sigma2_hat <- sum(residuals^2) / dfr

cat("OLS estimates:\n")
print(beta_hat)
cat("sigma^2_hat:", sigma2_hat, "\n\n")

xtable::xtable(rbind(c(x0 = 0.0005, lambda = .3, sigma2 = 0.1),
                     c(x0 = get.logistic(beta_hat[1]), lambda = beta_hat[2], sigma2 = sigma2_hat)), digits = 6)

#################################
## Uncertainty Quantification
#################################

## Fisher Information–based CI

CI.FIM.time <- system.time(FIM.res <- get.CI.FIM(X = X,
                                                 s2 = sigma2_hat,
                                                 beta = beta_hat,
                                                 alpha = 0.05))



cat("95% Fisher-based CI:\n")
print(FIM.res$CI_FIM)
cat("\n")

# Compute prediction interval using the FIM for all t values
PI.FIM.time <- system.time(PI_FIM <- t(sapply(t, FUN = function(i){
  get.PI_FIM(I_hat_i = FIM.res$cov_beta,
             sigma2_hat = sigma2_hat,
             alpha = 0.05,
             beta_hat = beta_hat,
             t0 = i,
             Y = Y)
})))
colnames(PI_FIM) <- c("lower", "upper")

############################
## Profile Likelihood CI
############################
#

pl_beta0.time <- system.time(pl_beta0 <- PL_CI(param = "beta0",
                                               beta_hat = beta_hat,
                                               sigma2_hat = sigma2_hat,
                                               se_beta = FIM.res$se_beta,
                                               grid_points = 2000,
                                               t = t,
                                               X = X,
                                               Y = Y))

pl_beta1.time <- system.time(pl_beta1 <- PL_CI(param = "beta1",
                                               beta_hat = beta_hat,
                                               sigma2_hat = sigma2_hat,
                                               se_beta = FIM.res$se_beta,
                                               grid_points = 2000,
                                               t = t,
                                               X = X,
                                               Y = Y))

CI_PL <- rbind(beta0 = pl_beta0$CI,
               beta1 = pl_beta1$CI)
colnames(CI_PL) <- c("lower", "upper")

cat("95% Profile Likelihood CI:\n")
print(CI_PL)
cat("\n")

# Comparing FIM parabola and PL for each beta
pdf(file = paste0(figPath, "FIMpar-PL-comparison.pdf"), width = 10, height = 4)
par(mar = c(4,3,1,1), mfrow = c(1,2), xpd=FALSE)
plot(pl_beta0$grid,
     -(pl_beta0$pl - max(pl_beta0$pl)),
     type='l', 
     lwd=2,
     xlab=expression(beta[0]), 
     ylab="",
     main="",
     col = "black",
     cex.axis = 1.5,
     cex.lab = 2)
segments(x0 = pl_beta0$CI[1],
         x1 = pl_beta0$CI[1],
         y0 = -10,
         y1 = -pl_beta0$thrres, # -(pl_beta0$thr - max(pl_beta0$pl)),
         col = "black",
         lty = 2)
segments(x0 = pl_beta0$CI[2],
         x1 = pl_beta0$CI[2],
         y0 = -10,
         y1 = -pl_beta0$thrres, # -(pl_beta0$thr - max(pl_beta0$pl)),
         col = "black",
         lty = 2)
lines(x = FIM.res$xyFIM.par.res[,1,1],
      y = -FIM.res$xyFIM.par.res[,2,1],
      col = "blue")
segments(x0 = FIM.res$CI_FIM["beta0",1],
         x1 = FIM.res$CI_FIM["beta0",1],
         y0 = -10,
         y1 = -(pl_beta0$thr - max(pl_beta0$pl)),
         col = "blue",
         lty = 2)
segments(x0 = FIM.res$CI_FIM["beta0",2],
         x1 = FIM.res$CI_FIM["beta0",2],
         y0 = -10,
         y1 = -(pl_beta0$thr - max(pl_beta0$pl)),
         col = "blue",
         lty = 2)
par(xpd=TRUE)
points(beta_hat[1], 0, 
       col="red",
       pch = "*",
       cex = 5)
par(xpd=FALSE)
plot(pl_beta1$grid,
     -(pl_beta1$pl - max(pl_beta0$pl)),
     type='l', 
     lwd=2,
     xlab=expression(beta[1]), 
     ylab="",
     main="",
     col = "black",
     cex.axis = 1.5,
     cex.lab = 2)
segments(x0 = pl_beta1$CI[1],
         x1 = pl_beta1$CI[1],
         y0 = -10,
         y1 = -pl_beta1$thrres, # -(pl_beta0$thr - max(pl_beta0$pl)),
         col = "black",
         lty = 2)
segments(x0 = pl_beta1$CI[2],
         x1 = pl_beta1$CI[2],
         y0 = -10,
         y1 = -pl_beta1$thrres, # -(pl_beta0$thr - max(pl_beta0$pl)),
         col = "black",
         lty = 2)
lines(x = FIM.res$xyFIM.par.res[,1,2],
      y = -FIM.res$xyFIM.par.res[,2,2],
      col = "blue")
segments(x0 = FIM.res$CI_FIM["beta1",1],
         x1 = FIM.res$CI_FIM["beta1",1],
         y0 = -10,
         y1 = -(pl_beta0$thr - max(pl_beta0$pl)),
         col = "blue",
         lty = 3)
segments(x0 = FIM.res$CI_FIM["beta1",2],
         x1 = FIM.res$CI_FIM["beta1",2],
         y0 = -10,
         y1 = -(pl_beta0$thr - max(pl_beta0$pl)),
         col = "blue",
         lty = 2)
par(xpd=TRUE)
points(beta_hat[2], 0, 
       col="red",
       pch = "*",
       cex = 5)
par(xpd = NA)
abline(h = -(pl_beta0$thr - max(pl_beta0$pl)),
       lwd = 3,
       col = "grey",
       lty = 2)
legend(x = "top",
       legend = c("FIM",
                  "PL"),
       col = c("blue",
               "black"),
       bty = 'n',
       lwd = 5,
       cex = 2)
dev.off()


########################################################
## Prediction Interval from Profile Likelihood CIs
########################################################

PI.PL.time <- system.time(PI_profile <- t(sapply(t, FUN = function(i){
  PI_PL(X = X,
        t_star = i,
        beta_hat = beta_hat,
        sigma2_hat = sigma2_hat,
        grid.length = 2,
        alpha = 0.05)
})))
colnames(PI_profile) <- c("lower", "upper")


####################################################
### Bayesian Posterior CI via Gibbs Sampling
####################################################

# Priors:
# beta | sigma2 ~ N(0, 1000 * I)
# sigma2 ~ Inv-Gamma(a0, b0)
nIT <- 5000
MCMC.time <- system.time(MCMC.res <- get.MCMC(X = X,
                                              Y = Y,
                                              V0 = diag(1000, 2),
                                              a0 = 0.001,
                                              b0 = 0.001,
                                              n_iter = nIT,
                                              beta0 = beta_hat,
                                              s20 = sigma2_hat))

# Fraction of posterior samples to use
n_post <- 0.5
MCMC.post <- tail(MCMC.res$beta_samples, nIT*n_post)
MCMC.post_s2 <- tail(MCMC.res$sigma2_samples, nIT*n_post)
CI_bayes <- apply(MCMC.post, 2, quantile, probs = c(0.025, 0.975))
rownames(CI_bayes) <- c("lower", "upper")
colnames(CI_bayes) <- c("beta0", "beta1")

CI_bayes_s2 <- quantile(MCMC.post_s2, probs = c(0.025, 0.975))

cat("95% Bayesian Credible Intervals (Gibbs):\n")
print(t(CI_bayes))
cat("\n")

# Comparing FIM parabola and PL for each beta
pdf(file = paste0(figPath, "Bayes-posterior.pdf"), width = 15, height = 4)
par(mar = c(4,3,1,1), mfrow = c(1,3))
hist(as.vector(MCMC.post[,1]),
     xlab=expression(beta[0]), 
     ylab="",
     main="",
     cex.axis = 2,
     cex.lab = 2.5,
     border = FALSE,
     probability = TRUE,
     breaks = 20)
abline(v = CI_bayes[,"beta0"], lty = 2)
par(xpd=TRUE)
points(mean(as.vector(MCMC.post[,1])), 0, 
       col="red",
       pch = "*",
       cex = 5)
par(xpd=FALSE)
hist(as.vector(MCMC.post[,2]),
     xlab=expression(beta[1]), 
     ylab="",
     main="",
     cex.axis = 2,
     cex.lab = 2.5,
     border = FALSE,
     probability = TRUE,
     breaks = 20)
abline(v = CI_bayes[,"beta1"], lty = 2)
par(xpd=TRUE)
points(mean(as.vector(MCMC.post[,2])), 0, 
       col="red",
       pch = "*",
       cex = 5)
par(xpd=FALSE)
hist(as.vector(MCMC.post_s2),
     xlab=expression(sigma^2), 
     ylab="",
     main="",
     cex.axis = 2,
     cex.lab = 2.5,
     border = FALSE,
     probability = TRUE,
     breaks = 20)
abline(v = CI_bayes_s2, lty = 2)
par(xpd=TRUE)
points(mean(as.vector(MCMC.post_s2)), 0, 
       col="red",
       pch = "*",
       cex = 5)
dev.off()

################################################
### Bayesian Posterior Predictive Interval 
################################################

PI_Bayes.time <- system.time(PI_bayes <- get.PI_Bayes(beta_post = MCMC.post,
                                                      sigma2_post = MCMC.post_s2,
                                                      Y = Y))


####################################################
#### Jackknife+ Conformal Prediction Intervals
####################################################

CPJKP.time <- system.time(CPJKP_PI <- t(sapply(t, function(t_new){
  get.JKP(x = t_new,
          X = X,
          Y = Y,
          alpha = 0.05)
})))

###################################
## plot all prediction intervals
###################################

pdf(file = paste0(figPath, "PIs-comparison.pdf"), width = 10, height = 4)
par(mar = c(4,5.5,1,1))
plot(t, 
     get.logistic(Y),
     xlab = "t",
     ylab = expression(e^y/(1 + e^y)),
     pch = 20,
     cex.axis = 2,
     cex.lab = 2)
lines(t,
      get.logistic(X %*% beta_hat),
      col = "red",
      lty = 2)
matplot(t, 
        get.logistic(PI_profile),
        add = TRUE,
        type = 'l',
        lty = 3,
        col = "blue")
matplot(t, 
        get.logistic(PI_FIM),
        add = TRUE,
        type = 'l',
        lty = 2,
        col = "red")
matplot(t, 
        get.logistic(PI_bayes),
        add = TRUE,
        type = 'l',
        lty = 4,
        col = "green")
lines(t,
      get.logistic(X %*% apply(MCMC.post, 2, mean)),
      col = "green",
      lty = 4)
matplot(t, 
        get.logistic(CPJKP_PI),
        add = TRUE,
        type = 'l',
        lty = 5,
        col = "pink")
legend(x = "bottomright",
       legend = c("OLS/FIM",
                  "PL",
                  "BP",
                  "CP"),
       col = c("red",
               "blue",
               "green",
               "pink"),
       lty = c(2,3,4,5),
       bty = "n",
       cex = 2,
       lwd = 3)
dev.off()

FIM.time <- (CI.FIM.time[3] + PI.FIM.time[3])
PL.time <- c(pl_beta0.time + pl_beta1.time + PI.PL.time)[3]
Bayesian.time <- (MCMC.time + PI_Bayes.time)[3]

xtable::xtable(t(c(FIM = FIM.time,
                 PL = PL.time,
                 B = Bayesian.time,
                 CP = CPJKP.time[3])), digits = 3)


xtable::xtable(rbind(c(x0 = 0.0005, lambda = .3, sigma2 = 0.1),
                     c(x0 = get.logistic(beta_hat[1]), 
                       lambda = beta_hat[2], 
                       sigma2 = sigma2_hat),
                     c(x0 = get.logistic(mean(MCMC.post[,1])), 
                       lambda = mean(MCMC.post[,2]), 
                       sigma2 = mean(MCMC.post_s2))), digits = 6)



