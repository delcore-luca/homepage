###################
## penalizedVARd ##
###################
##
## Description: This function takes the data y, the lag order d, 
##              and the penalty weight L as input, and returns a 
##              fitted VAR(d,L) model
##
penalizedVARd <- function(y, d, L){
  message("VAR(",d,")\tPenalty lambda = ", L)
  
  T <- nrow(y)
  p <- ncol(y)
  
  N <- T - d
  
  ## response matrix:
  Y <- y[(d+1):T,]
  
  ## design matrix:
  X <- Reduce(rbind, lapply((d+1):T, FUN = function(t){
    return(matrix(data = c(t(y[(t-1):(t-d),])), nrow = 1))
  }))
  
  ## MLS estimator of A:
  A_MLE <- t(solve(t(X) %*% X) %*% t(X) %*% Y)
  
  ## penalised inference (only for lambda != 0)
  if(L != 0){
    VARd_res <- penalizedLS(Y, X, L, A_MLE)
    A <- matrix(VARd_res$par, nrow = ncol(Y))
  }else{
    VARd_res <- list()
    A <- A_MLE
    VARd_res$par <- c(A_MLE)
  }
  
  VARd_res$lambda <- L
  VARd_res$d <- d
  VARd_res$A_MLE <- A_MLE
  VARd_res$A_lambda <- A
  
  # computing the sample covariance matrix S:
  Sigma <- 1/(T-d)*t(Y - X %*% t(A)) %*% (Y - X %*% t(A))
  
  # computing OLS of \Theta:
  Theta <- solve(Sigma)
  VARd_res$Theta <- Theta
  
  # computing AIC:
  p_nz <- sum(VARd_res$par != 0) + p*(p + 1)/2 # n. of non-zero parameters
  n_eff <- T - d
  VARd_res$AIC <- 2*p_nz - n_eff*log(det(VARd_res$Theta))
  VARd_res$BIC <- log(n_eff)*p_nz - n_eff*log(det(VARd_res$Theta))
  
  A <- t(A)
  As <- lapply(1:d, FUN = function(b){t(A[((b-1)*p+1):(b*p), ])})
  Comp <-  Matrix(rbind(Reduce(cbind, As), 
                        cbind(Diagonal((d-1)*p,1), 
                              Matrix(data = 0, 
                                     nrow = (d-1)*p, 
                                     ncol = p, sparse = TRUE))), 
                  sparse = TRUE)
  
  VARd_res$As <- As
  
  if(sum(sapply(eigen(Comp, only.values = TRUE)$values, Mod) > 1) == 0){
    return(VARd_res)
  }else{
    return("process is not stationary")
  }
  
}

###################
## penalizedVARd ##
###################
##
## Description: This function takes the response matrix Y, 
##              the design matrix X, the penalty weight L, 
##              and the MLE estimate of A as input, 
##              and performs the optimization 
##              of a VAR(d,L) model.
##
penalizedLS <- function(Y, X, L, A_MLE){
  
  A_LB <- matrix(data = -Inf, nrow = nrow(A_MLE), ncol = ncol(A_MLE))
  A_UB <- matrix(data = Inf, nrow = nrow(A_MLE), ncol = ncol(A_MLE))
  
  A_UB[A_MLE < 0] <- 0
  A_LB[A_MLE >= 0] <- 0
  
  psi_LB <- c(A_LB)
  psi_UB <- c(A_UB)
  
  psi_MLE <- c(A_MLE)
  
  LS_res <- optim(par = psi_MLE,
                  fn = nl,
                  gr = gnl,
                  l = L, Y = Y, X = X,
                  method = "L-BFGS-B",
                  lower = psi_LB,
                  upper = psi_UB,
                  # method = "BFGS",
                  control = list(maxit = 10000, 
                                 factr = 1e7, 
                                 pgtol = 0, 
                                 lmm = 5, 
                                 trace = TRUE))
  
  return(LS_res)
}

########
## nl ##
########
##
## Description: This function takes the response matrix Y, 
##              the design matrix X, the penalty weight l, 
##              and psi = c(A) as input parameters, 
##              and calculates the negative log-likelihood 
##              of a VAR(d,l) model.
##
nl <- function(psi, l, Y, X){
  A <- matrix(psi, nrow = ncol(Y))
  NL <- as.numeric(-2*tr(A %*% t(X) %*% Y) 
                   + tr(A %*% t(X) %*% X %*% t(A)) + l*L1(A))
  return(NL)
}

#########
## gnl ##
#########
##
## Description: This function takes the response matrix Y, 
##              the design matrix X, the penalty weight l, 
##              and psi = c(A) as input parameters, 
##              and calculates the gradient of 
##              the negative log-likelihood of a VAR(d,l) model.
##
gnl <- function(psi, l, Y, X){
  A <- matrix(psi, nrow = ncol(Y))
  NG <- c(-2*t(Y) %*% X + 2*A%*%t(X)%*%X + l*sign(A))
  return(NG)
}

########
## tr ##
########
##
## Description: This function takes a square matrix as input, 
##              and returns its trace.
##
tr <- function(A){
  sum(diag(A))
}

########
## L1 ##
########
##
## Description: This function takes a matrix/vector as input, 
##              and returns its L1 norm.
##
L1 <- function(x){
  sum(abs(x))
}

############
## rotate ##
############
##
## Description: This function takes a square matrix as input, 
##              and returns its rotation.
##
rotate <- function(x){
  return(t(apply(x, 2, rev)))
} 
