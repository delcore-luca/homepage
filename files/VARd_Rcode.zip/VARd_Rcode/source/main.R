
library(psych)
library(Matrix)

source("./source/fun.R")

####################
## create folders ##
####################

resPath <- paste("./results/", sep = "")
ifelse(!dir.exists(file.path(resPath)), 
       dir.create(file.path(resPath)), FALSE)
figPath <- paste0(resPath, "figures/")
ifelse(!dir.exists(file.path(figPath)), 
       dir.create(file.path(figPath)), FALSE)


#### LOAD DATA ####
Y <- as.matrix(unlist(EuStockMarkets))
tp <- 1:nrow(Y)
Ytp <- cbind(tp, Y)
colnames(Ytp) <- c("t", colnames(Y))

## diagnostics analysis 1
pdf(file = paste(figPath, "/resFit.pdf", sep = ""), 
    height = 7, 
    width = 12)
par(mar = c(5,5,2,2), mfrow = c(2,2))
apply(Y, 2, FUN = function(s){
  plot(lm(s ~ tp)$fitted, lm(s ~ tp)$residuals, 
       lty = 1, 
       lwd = 2, 
       cex.axis = 1.5, 
       pch = 20, 
       cex.lab = 2, 
       ylab = "residuals", 
       xlab = "fitted")
})
dev.off()

## diagnostics analysis 2
pdf(file = paste(figPath, "/pairWiseCorr.pdf", sep = ""), 
    height = 5, 
    width = 5)
pairs.panels(Ytp, 
             method = "spearman", # correlation method
             hist.col = "#00AFBB",
             density = TRUE,  # show density plots
             ellipses = FALSE, # show correlation ellipses
             xaxt = 'n', yaxt = 'n')
dev.off()

pdf(file = paste(figPath, "/timeSeries.pdf", sep = ""), 
    height = 5, 
    width = 5)
par(mar = c(5,5,2,2))
matplot(Y, 
        type = 'l', 
        lty = 1, 
        lwd = 2, 
        cex.axis = 2, 
        cex.lab = 2, 
        ylab = "stocks", 
        xlab = "time (days)")
legend(x = "topleft", 
       legend = colnames(Y), 
       pch = 20, 
       col = 1:ncol(Y), 
       lty = 1, 
       lwd = 5, 
       cex = 1.5)
dev.off()

#### RESCALED DATA ####
Y <- log(Y)
Y <- apply(Y, 2, diff)
Y <- apply(Y, 2, function(y){y - mean(y)})

tp <- 1:nrow(Y)
Ytp <- cbind(tp, Y)
colnames(Ytp) <- c("t", colnames(Y))

## diagnostics analysis 1
pdf(file = paste(figPath, "/resFit_res.pdf", sep = ""), 
    height = 7, 
    width = 12)
par(mar = c(5,5,2,2), mfrow = c(2,2))
apply(Y, 2, FUN = function(s){
  plot(lm(s ~ tp)$fitted, lm(s ~ tp)$residuals, 
       lty = 1, 
       lwd = 2, 
       cex.axis = 1.5, 
       pch = 20, 
       cex.lab = 2, 
       ylab = "residuals", 
       xlab = "fitted")
})
dev.off()

## diagnostics analysis 2
pdf(file = paste(figPath, "/pairWiseCorr_res.pdf", sep = ""), 
    height = 5, 
    width = 5)
pairs.panels(Ytp, 
             method = "spearman", # correlation method
             hist.col = "#00AFBB",
             density = TRUE,  # show density plots
             ellipses = FALSE, # show correlation ellipses
             xaxt = 'n', yaxt = 'n')
dev.off()

pdf(file = paste(figPath, "/timeSeries_res.pdf", sep = ""), 
    height = 5, 
    width = 5)
par(mar = c(5,5,2,2))
matplot(Y, 
        type = 'l', 
        lty = 1, 
        lwd = 2, 
        cex.axis = 2, 
        cex.lab = 2, 
        ylab = "stocks", 
        xlab = "time (days)")
legend(x = "bottom", 
       legend = colnames(Y), 
       pch = 20, 
       col = 1:ncol(Y), 
       lty = 1, 
       lwd = 5, 
       cex = 1.5)
dev.off()

## set order d and penalty weight lambda:
all_d <- c(7,15,30,45) ## candidate orders
all_lambda <- c(0, .001, .005, .05) ## candidate penalty weights
dL <- matrix(data = c(rep(all_d, each = length(all_lambda)), 
                      rep(all_lambda, times = length(all_d))), 
             ncol = 2)

## penalized optimiziation for each combination of d and lambda
fitRes <- lapply(1:nrow(dL), function(r){
  penalizedVARd(y = Y, 
                d = dL[r,1], 
                L = dL[r,2])
})

AICs <- as.vector(unlist(lapply(fitRes, function(l){l[["AIC"]]})))
BICs <- as.vector(unlist(lapply(fitRes, function(l){l[["BIC"]]})))
ds <- as.vector(unlist(lapply(fitRes, function(l){l[["d"]]})))
Ls <- as.vector(unlist(lapply(fitRes, function(l){l[["lambda"]]})))

d_AIC <- which(AICs == min(AICs, na.rm = TRUE)) # best AIC model
d_BIC <- which(BICs == min(BICs, na.rm = TRUE)) # best BIC model
par_d <- fitRes[[d_AIC]]$par
d <- fitRes[[d_AIC]]$d
p <- ncol(Y)
A <- t(fitRes[[d_AIC]]$A_lambda)
As <- lapply(1:d, FUN = function(b){t(A[((b-1)*p+1):(b*p), ])})
Theta <- fitRes[[d_AIC]]$Theta

## model selection results:
clrs <- rep("black", length(AICs))
clrs[d_AIC] <- "red"
clrs[d_BIC] <- "blue"
pdf(file = paste(figPath, "/ICs.pdf", sep = ""), 
    height = 5, width = 5)
par(mar = c(5,6,2,2))
plot(ds, rep(1:(length(all_lambda)), times = length(all_d)), 
     cex = 2*exp(AICs/max(AICs)), cex.axis = 2, cex.lab = 2, 
     xaxt = 'n', yaxt = 'n',
     xlab = "d", ylab = expression(lambda), pch = 20, col = clrs)
axis(1, at=unique(ds), labels=unique(ds), cex.axis = 1.5)
axis(2, at=1:length(all_lambda), labels = unique(Ls), cex.axis = 1.5)
dev.off()

## results of best AIC model
pdf(file = paste(figPath, "/A_Theta_AIC.pdf", sep = ""), 
    height = 5, 
    width = 10)
par(mar = c(2,3,2,2), mfrow = c(2,4))
for(l in rev(1:length(As))){
  image(rotate(abs(As[[l]])), 
        xaxt='n', 
        yaxt = 'n', 
        main = paste("A: t - ", l), 
        cex.main = 2, 
        zlim = range(abs(as.vector(unlist(As))))) # 
  axis(1, 
       at = seq(0,1,length.out = p), 
       labels= apply(matrix(colnames(Y)), 1, substr, 1, 1), 
       font = 2, 
       cex.axis = 2)
  axis(2, 
       at = seq(0,1,length.out = p), 
       labels= rev(apply(matrix(colnames(Y)), 1, substr, 1, 1)), 
       font = 2, 
       cex.axis = 2)
}
image(rotate(abs(Theta)), 
      xaxt='n', 
      yaxt = 'n', 
      main = expression(Theta), 
      cex.main = 2)
axis(1, 
     at = seq(0,1,length.out = p), 
     labels= apply(matrix(colnames(Y)), 1, substr, 1, 1), 
     font = 2, 
     cex.axis = 2)
axis(2, 
     at = seq(0,1,length.out = p), 
     labels= rev(apply(matrix(colnames(Y)), 1, substr, 1, 1)), 
     font = 2, 
     cex.axis = 2)
dev.off()

## results of best BIC model
par_d <- fitRes[[d_BIC]]$par
d <- fitRes[[d_BIC]]$d
p <- ncol(Y)
A <- t(fitRes[[d_BIC]]$A_lambda)
As <- lapply(1:d, FUN = function(b){t(A[((b-1)*p+1):(b*p), ])})
Theta <- fitRes[[d_BIC]]$Theta

pdf(file = paste(figPath, "/A_Theta_BIC.pdf", sep = ""), 
    height = 5, 
    width = 10)
par(mar = c(2,3,2,2), mfrow = c(2,4))
for(l in rev(1:length(As))){
  image(rotate(abs(As[[l]])), 
        xaxt='n', 
        yaxt = 'n', 
        main = paste("A: t - ", l), 
        cex.main = 2, 
        zlim = range(abs(as.vector(unlist(As))))) # 
  axis(1, 
       at = seq(0,1,length.out = p), 
       labels= apply(matrix(colnames(Y)), 1, substr, 1, 1), 
       font = 2, 
       cex.axis = 2)
  axis(2, 
       at = seq(0,1,length.out = p), 
       labels= rev(apply(matrix(colnames(Y)), 1, substr, 1, 1)), 
       font = 2, 
       cex.axis = 2)
}
image(rotate(abs(Theta)), 
      xaxt='n', 
      yaxt = 'n', 
      main = expression(Theta), 
      cex.main = 2)
axis(1, 
     at = seq(0,1,length.out = p), 
     labels= apply(matrix(colnames(Y)), 1, substr, 1, 1), 
     font = 2, 
     cex.axis = 2)
axis(2, 
     at = seq(0,1,length.out = p), 
     labels= rev(apply(matrix(colnames(Y)), 1, substr, 1, 1)), 
     font = 2, 
     cex.axis = 2)
dev.off()
