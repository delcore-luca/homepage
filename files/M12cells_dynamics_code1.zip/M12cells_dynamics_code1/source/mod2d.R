
## Required packages
library(deSolve)
library(spsUtil)
library(Matrix)
library(MASS)
library(pracma)

## Required functions
source("./source/load-data.R")
source("./source/allFun.R")
source("./source/mod2d-fun.R")
source("./source/PLfun.R")
source("./source/cmaes.R")


##############
## currTime ##
##############

currTime <- Sys.time()
currTime <- gsub(" ", "_", currTime)
currTime <- gsub("-", "", currTime)
currTime <- gsub(":", "", currTime)
currTime <- paste(currTime,
                  "_mod2d", sep = "_")

#############
## folders ##
#############

currDir <- getwd()
setwd(currDir)

#############
## folders ##
#############

resPath <- paste("./results", sep = "")
ifelse(!dir.exists(file.path(resPath)), dir.create(file.path(resPath)), FALSE)
resPath <- paste0(paste(resPath, currTime, sep = "/"), "/")
figPath <- paste0(resPath, "figures/")

ifelse(!dir.exists(file.path(resPath)), dir.create(file.path(resPath)), FALSE)
ifelse(!dir.exists(file.path(figPath)), dir.create(file.path(figPath)), FALSE)


#############################
# Analysing averaged data:
#############################


##############################
## Frequentist Analysis (MLE)
##############################

nFit <- 100 # number of starting parameter guesses
allpsi.c <- matrix(data = get.logit(runif(4*nFit, 0, .1)),
                   ncol = nFit,
                   nrow = 4) # starting parameter guesses

# perform MLE for each starting parameter, using BFGS
time.start.MLE.BFGS <- proc.time()[3]
all.res.MLE.BFGS <- lapply(1:nFit, function(j){
  res.MLE <- optim(par = allpsi.c[,j], # res.cmaes$x.best,
                   fn = nl.try,
                   gr = gnl.try,
                   method = "BFGS",
                   Y = log(Y0_mean),
                   G = (obs.idx_mean == TRUE),
                   times = tps,
                   hmax = .1, # max(tps),
                   control = list(maxit = 10000,
                                  reltol = 1e-32,
                                  trace = 1,
                                  REPORT = 10))
  
  return(list(f_opt = res.MLE$value,
              res = res.MLE))
})
time.end.MLE.BFGS <- proc.time()[3]
MLE.BFGS.time <- time.end.MLE.BFGS - time.start.MLE.BFGS

# get the best estimate
wMin <- order(sapply(all.res.MLE.BFGS, function(res){
  res$f_opt}), 
  decreasing = FALSE)[1]
res.MLE.BFGS <- all.res.MLE.BFGS[[wMin]]$res

# perform MLE for each starting parameter using CMAES
time.start.MLE.CMAES <- proc.time()[3]
all.res.MLE.CMAES <- lapply(1:nFit, function(j){
  res.MLE <- cmaes(par = allpsi.c[,j],
                   fun = nl.try,
                   Y = log(Y0_mean),
                   G = (obs.idx_mean == TRUE),
                   times = tps,
                   hmax = .1, # max(tps),
                   control = list(verbose = TRUE,
                                  maxIT = 500,
                                  maxTime = 3, # in hours
                                  xtol = 1e-4,
                                  ftol = 1e-6,
                                  REPORT = 10,
                                  local = FALSE),
                   cmaes.init = list(N = length(allpsi.c[,j]),
                                     xmean = allpsi.c[,j],
                                     sigma = .1))
  
  return(list(f_opt = res.MLE$value,
              res = res.MLE))
})
time.end.MLE.CMAES <- proc.time()[3]
MLE.CMAES.time <- time.end.MLE.CMAES - time.start.MLE.CMAES

# get the best estimate
wMin.CMAES <- order(sapply(all.res.MLE.CMAES, function(res){
  res$res$f.best}), 
  decreasing = FALSE)[1]
res.MLE.CMAES <- all.res.MLE.CMAES[[wMin.CMAES]]$res


# # calculate BIC
# BIC_mod2d_avgdata <- get.BIC(nl = res.MLE.CMAES$f.best,
#                              p = length(res.MLE.CMAES$x.best),
#                              N = prod(dim(Y0_mean)))
# # BIC = -702.1217
# # BIC = -690.0188

## time grid for predictions
tps.pred <- seq(0, 50, length.out = 1000)

## 95% Fisher Information based confidence intervals
FIM_CIs <- get.FIM.CI(psi = res.MLE.CMAES$x, # res.MLE$par,
                      times = tps,
                      hmax = 0.1,
                      Y = log(Y0_mean),
                      G = (obs.idx_mean == TRUE),
                      alpha = 0.05)

## 95% Fisher Information based prediction intervals
FIM.PI <- get.FIM.PI(psi = res.MLE.CMAES$x, # res.MLE$par,
                     times = tps,
                     times.pred = tps.pred,
                     hmax = 0.1,
                     Y = log(Y0_mean),
                     G = (obs.idx_mean == TRUE),
                     fn = nl.try,
                     gr = gnl.try,
                     alpha = 0.05,
                     mNoise = FALSE)

## Display model fit and prediction intervals
pdf(paste0(figPath, "/2d-fit-avg.pdf"), width = 7, height = 4)
par(mar = c(4,6,1,1))
matplot(x = tps.pred,
        y = FIM.PI$m,
        ylim = range(FIM.PI$PI_l, FIM.PI$PI_u, Y0_mean,
                     na.rm = TRUE),
        lty = 1,
        lwd = 2,
        type = 'l',
        cex.axis = 2,
        cex.lab = 2,
        xlab = "time (days)",
        ylab = "cell count"
)
matplot(x = tps,
        y = Y0_mean[,,1],
        ylim = range(FIM.PI$PI_l, FIM.PI$PI_u, Y0_mean,
                     na.rm = TRUE),
        type = 'p',
        pch = 20,
        add = TRUE,
        cex = 2,
        col = scales::alpha(c("black", "red"), alpha = .8)
)
matplot(x = tps.pred,
        y = FIM.PI$PI_l, 
        type = 'l',
        lty = 2,
        lwd = 2,
        add = TRUE)
matplot(x = tps.pred,
        y = FIM.PI$PI_u, 
        type = 'l',
        lty = 2,
        lwd = 2,
        add = TRUE)
dev.off()

###################################
## Calculate Profile Likelihood
##################################

## Get s2 estimator under MLE
s2_hat <- get.s2(psi = res.MLE.BFGS$par,
                 Y = log(Y0_mean),
                 G = (obs.idx_mean == TRUE),
                 times = tps,
                 hmax = .1)

time.start.PL.BFGS <- proc.time()[3]
PLjs.res.BFGS <- lapply(1:length(res.MLE.BFGS$par), function(j){
  cat(paste0("PL for ", j, "-th parameter...\n"))
  PLj.res <- get.PL(psi_MLE = res.MLE.BFGS$par,
                    f_MLE = res.MLE.BFGS$value,
                    s2_hat = s2_hat,
                    fn = nl.PL.try,
                    gr = gnl.PL.try,
                    method = "optim",
                    j = j,
                    Y = log(Y0_mean),
                    G = (obs.idx_mean == TRUE),
                    times = tps,
                    hmax = max(tps),
                    maxIT = 30)
  return(PLj.res)
})
time.end.PL.BFGS <- proc.time()[3]
PL.BFGS.time <- time.end.PL.BFGS - time.start.PL.BFGS
# elapsed 
# 101.639

## Get s2 estimator under MLE
s2_hat <- get.s2(psi = res.MLE.CMAES$x.best,
                 Y = log(Y0_mean),
                 G = (obs.idx_mean == TRUE),
                 times = tps,
                 hmax = .1)

time.start.PL.CMAES <- proc.time()[3]
PLjs.res.CMAES <- lapply(1:length(res.MLE.CMAES$x.best), function(j){
  cat(paste0("PL for ", j, "-th parameter...\n"))
  PLj.res <- get.PL(psi_MLE = res.MLE.CMAES$x.best,
                    f_MLE = res.MLE.CMAES$f.best,
                    s2_hat = s2_hat,
                    fn = nl.PL.try,
                    # gr = gnl.PL.try,
                    # method = "optim",
                    method = "cmaes",
                    cmaes.control = list(verbose = FALSE,
                                         maxIT = 1000,
                                         maxTime = 3,
                                         xtol = 1e-4,
                                         ftol = 1e-4,
                                         REPORT = 10,
                                         local = FALSE),
                    j = j,
                    Y = log(Y0_mean),
                    G = (obs.idx_mean == TRUE),
                    times = tps,
                    hmax = max(tps),
                    maxIT = 30)
  return(PLj.res)
})
time.end.PL.CMAES <- proc.time()[3]
PL.CMAES.time <- time.end.PL.CMAES - time.start.PL.CMAES
# elapsed 
# 282.686

############################################
## Wald-type confidence ellipses using MLE
############################################

## Get s2 estimator under MLE
s2_hat <- get.s2(psi = res.MLE.BFGS$par, # res.MLE.CMAES$x.best,
                 Y = log(Y0_mean),
                 G = (obs.idx_mean == TRUE),
                 times = tps,
                 hmax = .1)

## Get Hessian matrix of the posterior negative log-likelihood
H.MLE <- optimHess(par = res.MLE.BFGS$par, # res.MLE.CMAES$x.best,
                   fn = nl.try,
                   gr = gnl.try,
                   Y = log(Y0_mean),
                   G = (obs.idx_mean == TRUE),
                   times = tps,
                   hmax = .1,
                   control = list(maxit = 10000,
                                  reltol = 1e-32,
                                  trace = 1,
                                  REPORT = 1))

pdf(paste0(figPath, "/2d-MLE-ellipses-avg.pdf"), width = 5, height = 4)
par(mar = c(4,6,1,1))
get.ellipse(phi = res.MLE.CMAES$x.best, # res.MLE$par,
            levels = c(.99, .95, .9),
            fim = H.MLE,
            s2 = s2_hat)
dev.off()

##############################
## for FIM-based parabolas
Cov <- solve(H.MLE) * 2*s2_hat

################################
## Display Profile Likelihood
################################
pdf(paste0(figPath, "/2d-PL-avg.pdf"), width = 9, height = 4)
par(mar = c(2,2.5,.5,.5), mfrow = c(1,4))
sapply(1:length(res.MLE.CMAES$x.best), function(j){
  
  # FIM-based parabola for j-th parameter
  theta_hat <- res.MLE.BFGS$par[j]
  f_hat <- res.MLE.BFGS$value
  var_j <- Cov[j,j]
  PL_quad <- f_hat + 0.5*(PLjs.res.BFGS[[j]]$PL_curve[,1] - theta_hat)^2/var_j
  
  plot(PLjs.res.BFGS[[j]]$PL_curve, 
       type = 'l',
       bty = ifelse(j == 1, "l", "n"),
       yaxt = ifelse(j == 1, "s", "n"),
       cex.axis = 2,
       cex.lab = 2,
       xlim = range(FIM_CIs[j,], PLjs.res.BFGS[[j]]$PL_curve[,1]),
       ylim = range(sapply(1:length(res.MLE.CMAES$x.best), function(j){
         range(PLjs.res.BFGS[[j]]$PL_curve[,2])})),
       lwd = 3)
  lines(PLjs.res.CMAES[[j]]$PL_curve, 
        type = 'l',
        bty = ifelse(j == 1, "l", "n"),
        yaxt = ifelse(j == 1, "s", "n"),
        ylim = range(sapply(1:length(res.MLE.CMAES$x.best), function(j){
          range(PLjs.res.CMAES[[j]]$PL_curve[,2])})),
        lwd = 3,
        lty = 2,
        col = "cyan")
  lines(PLjs.res.BFGS[[j]]$PL_curve[,1],
        PL_quad,
        col = "red",
        lwd = 3,
        lty = 3)
  if(j == 1) abline(h = PLjs.res.CMAES[[j]]$thr, xpd = NA, lwd = 2)
  abline(v = PLjs.res.CMAES[[j]]$PL_IC)
  abline(v = FIM_CIs[j,],
         col = "grey", lwd = 2, lty = 2)
  points(x = res.MLE.CMAES$x.best[j],
         y = res.MLE.CMAES$f.best,
         pch = "*",
         cex = 7)
})
dev.off()



save.image(paste0(resPath,"/mod2d-res.RData"))

