
## Raw data
Y <- matrix(data = c(1,0,0,1, # Hu et al. M1
                     1,1,5,1,
                     1,3,375,1,
                     1,5,325,1,
                     1,7,600,1,
                     1,14,750,1,
                     2,0,0,1, # Hu et al. M2
                     2,1,170,1,
                     2,3,300,1,
                     2,5,800,1,
                     2,7,600,1,
                     2,14,200,1,
                     1, 3, 62, 2, # Li (2018) et al. M1
                     1, 7, 55, 2, # Li (2018)  et al. M1
                     2, 1, 15, 2, # Li (2018)  et al. M2
                     2, 3, 15, 2, # Li (2018)  et al. M2          
                     2, 7, 6, 2, # Li (2018)  et al. M2
                     1, 2, 120, 3, # Ma et al. M1
                     2, 2, 90, 3, # Ma et al. M2
                     1, 14, 400, 4, # Wang et al. M1
                     2, 14, 110, 4, # Wang et al. M2
                     1, 3, 102, 5, # Xu et al. M1
                     2, 3, 57, 5, # Xu et al. M2
                     1, 2, 125, 6, # Li (2023)  et al. M1
                     2, 2, 269, 6, # Li (2023)  et al. M2
                     1,0,10,7, # Suenega et al. M1
                     1,1,50,7,
                     1,3,100,7,
                     1,7,900,7,
                     1,14,1300,7,
                     2,0,10,7, # Suenega et al. M2
                     2,1,50,7,
                     2,3,100,7,
                     2,7,400,7,
                     2,14,100,7,
                     1,3,60,8, # Yang et al. M1
                     1,7,225,8,
                     2,3,160,8, # Yang et al. M2
                     2,7,270,8),
            byrow = TRUE,
            ncol = 4)

# unique time points and studies
times  <- sort(unique(Y[, 2]))
studies <- sort(unique(Y[, 4]))

# initialize empty array
Y0 <- array(NA,
            dim = c(length(times), 2, length(studies)),
            dimnames = list(
              Time = times,
              Group = c("M1", "M2"),
              Study = studies
            ))

# fill the array
for (i in seq_len(nrow(Y))) {
  g <- Y[i, 1]   # group (1 or 2)
  t <- Y[i, 2]   # time
  v <- Y[i, 3]   # value
  s <- Y[i, 4]   # study
  
  Y0[as.character(t), g, as.character(s)] <- v
}
rm(i)
rm(g)
rm(t)
rm(v)
rm(s)

# Y0[Y0 == 0] <- NA # 0 = undetected

obs.idx <- array(1,
                 dim = c(length(times), 2, length(studies)),
                 dimnames = list(
                   Time = times,
                   Group = c("M1", "M2"),
                   Study = studies
                 ))
obs.idx[is.na(Y0)] <- 0

## Get average data across studies:
Y0_mean <- array(apply(Y0, c(1,2), mean, na.rm = TRUE), 
                 dim = c(dim(Y0)[1:2], 1))

obs.idx_mean <- Y0_mean
obs.idx_mean[] <- 1


tps <- as.numeric(rownames(Y0))

rm(times)
rm(studies)


