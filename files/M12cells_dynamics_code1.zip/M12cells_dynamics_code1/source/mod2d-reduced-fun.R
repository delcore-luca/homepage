
get.nl <- function(psi,
                   Y,
                   G,
                   times,
                   hmax = .01){
  
  r <- exp(psi[1])
  d <- exp(psi[2])
  l21 <- exp(psi[3])
  m1 <- exp(Y[1,1,1])
  m2 <- exp(Y[1,2,1])
  
  
  J <- dim(Y)[3]
  
  X <- try(vode(y = c(m1 = m1,
                      m2 = m2),
                times = times,
                func = get.dx,
                parms = c(r = r,
                          d = d,
                          l21 = l21),
                mf = -21, # -21
                jacfunc = get.jacF,
                hmax = hmax)[,-1], silent = TRUE)
  
  X[X < 0] <- 1e-8
  
  X <- replicate(J, X)
  X <- X[G]
  Y <- Y[G]
  
  H <- log(X)
  nl <- as.numeric(-2*t(H)%*%Y + t(H)%*%H)
  
  return(nl)
}

get.s2 <- function(psi,
                   Y,
                   G,
                   times,
                   hmax = .01){
  
  r <- exp(psi[1])
  d <- exp(psi[2])
  l21 <- exp(psi[3])
  m1 <- exp(Y[1,1,1])
  m2 <- exp(Y[1,2,1])
  
  
  J <- dim(Y)[3]
  
  X <- try(vode(y = c(m1 = m1,
                      m2 = m2),
                times = times,
                func = get.dx,
                parms = c(r = r,
                          d = d,
                          l21 = l21),
                mf = -21, # -21
                jacfunc = get.jacF,
                hmax = hmax)[,-1], silent = TRUE)
  
  X[X < 0] <- 1e-8
  
  X <- replicate(J, X)
  X <- X[G]
  Y <- Y[G]
  
  H <- log(X)
  # s2_hat <- as.numeric(t(Y - H) %*% (Y - H))/length(Y)
  s2_hat <- as.numeric(t(Y - H) %*% (Y - H))/(length(Y) - length(psi))
  
  return(s2_hat)
}


get.mu <- function(psi,
                   times,
                   hmax = .01,
                   Y){
  
  r <- exp(psi[1])
  d <- exp(psi[2])
  l21 <- exp(psi[3])
  m1 <- exp(Y[1,1,1])
  m2 <- exp(Y[1,2,1])
  
  X <- try(vode(y = c(m1 = m1,
                      m2 = m2),
                times = times,
                func = get.dx,
                parms = c(r = r,
                          d = d,
                          l21 = l21),
                mf = -21, # -21
                jacfunc = get.jacF,
                hmax = hmax)[,-1], silent = TRUE)
  
  return(X)
}

get.gnl <- function(psi,
                    Y,
                    G,
                    times,
                    hmax = .01){
  
  r <- exp(psi[1])
  d <- exp(psi[2])
  l21 <- exp(psi[3])
  m1 <- exp(Y[1,1,1])
  m2 <- exp(Y[1,2,1])
  
  np <- length(psi)
  nx <- 2
  
  J <- dim(Y)[3] # n. of clones
  
  XS <- try(vode(y = c(m1 = m1,
                       m2 = m2,
                       s11 = 0,
                       s12 = 0,
                       s21 = 0,
                       s22 = 0,
                       s31 = 0,
                       s32 = 0),
                       # s41 = 1,
                       # s42 = 1),
                 times = times,
                 func = get.dx.ws,
                 parms = c(r = r,
                           d = d,
                           l21 = l21),
                 # mf = -21, # -21
                 # jacfunc = get.jacF,
                 hmax = hmax)[,-1], silent = TRUE)
  
  X <- XS[,1:2]
  S <- XS[,-c(1,2)]
  
  X[X < 0] <- 1e-8
  
  X <- replicate(J, X)
  
  X <- X[G]
  Y <- Y[G]
  
  S <- S[,c(t(matrix(data = 1:(np*nx), ncol = nx, byrow = TRUE)[rep(1:np, each = J),]))]
  S <- matrix(data = S[matrix(data = c(G), nrow = length(times), ncol = np*nx*J)], ncol = np)
  
  H <- log(X)
  dH <- 1/X*S
  gnl <- as.numeric(-2*t(dH)%*%Y + 2*t(dH)%*%H)*exp(psi)
  
  return(gnl)
}

get.gY <- function(psi,
                   times,
                   hmax = .01,
                   Y){
  
  r <- exp(psi[1])
  d <- exp(psi[2])
  l21 <- exp(psi[3])
  m1 <- exp(Y[1,1,1])
  m2 <- exp(Y[1,2,1])
  
  np <- length(psi)
  nx <- 2
  
  XS <- try(vode(y = c(m1 = m1,
                       m2 = m2,
                       s11 = 0,
                       s12 = 0,
                       s21 = 0,
                       s22 = 0,
                       s31 = 0,
                       s32 = 0),
                       # s41 = 1,
                       # s42 = 1),
                 times = times,
                 func = get.dx.ws,
                 parms = c(r = r,
                           d = d,
                           l21 = l21),
                 # mf = -21, # -21
                 # jacfunc = get.jacF,
                 hmax = hmax)[,-1], silent = TRUE)
  
  X <- XS[,1:2]
  S <- XS[,-c(1,2)]
  
  X[X < 0] <- 1e-8
  

  S1 <- S[,rep(c(TRUE,FALSE), times = np)]
  S2 <- S[,rep(c(FALSE,TRUE), times = np)]
  
  # H <- log(X)
  dH1 <- 1/X[,1]*S1
  dH2 <- 1/X[,2]*S2

  gY1 <- dH1*matrix(data = exp(psi),
                    nrow = nrow(dH1),
                    ncol = length(psi),
                    byrow = TRUE)
  
  gY2 <- dH2*matrix(data = exp(psi),
                    nrow = nrow(dH2),
                    ncol = length(psi),
                    byrow = TRUE)
  
  return(list(gY1,
              gY2))
}


get.dx.ws <- function(t,
                      y, 
                      parms){
  m1 <- y["m1"]
  m2 <- y["m2"]
  
  np <- 3 # 4
  
  S <- matrix(y[3:(2 + 2*np)], nrow = 2, ncol = np)
  
  r <- parms["r"]
  d <- parms["d"]
  l21 <- parms["l21"]
  
  f <- c(r*m1 - d*m1*(m1 + m2) + l21*m2,
         r*m2 - d*m2*(m1 + m2) - l21*m2)
  
  # Jacobian
  Jf <- matrix(data = c(r - d*(2*m1 + m2), -d*m1 + l21,
                        -d*m2, r - d*(m1 + 2*m2) - l21),
               nrow = 2, ncol = 2,
               byrow = TRUE)
  
  # df/dtheta
  df_dtheta <- matrix(data = c(m1, m2, # r
                               -m1*(m1 + m2), -m2*(m1 + m2), # d
                               m2, -m2), # l21
                               # 0,0), # m1(0) / m2(0)
                      nrow = 2)
  
  dS <- Jf %*% S + df_dtheta
  
  return(list(c(f, as.vector(dS))))
}

get.dx <- function(t,
                   y, 
                   parms){
  m1 <- y["m1"]
  m2 <- y["m2"]
  
  r <- parms["r"]
  d <- parms["d"]
  l21 <- parms["l21"]
  
  
  f <- c(r*m1 - d*m1*(m1 + m2) + l21*m2,
         r*m2 - d*m2*(m1 + m2) - l21*m2)
  
  return(list(f))
}


# ## Fisher Information based prediction intervals
get.FIM.PI <- function(psi,
                       times,
                       times.pred,
                       hmax,
                       Y,
                       G,
                       fn,
                       gr,
                       mu = NULL,
                       Sigmai = NULL,
                       alpha,
                       mNoise = FALSE){
  
  if(is.null(mu) & is.null(Sigmai)){
    H.res <- optimHess(par = psi,
                       fn = fn,
                       gr = gr,
                       Y = Y,
                       G = G,
                       times = times,
                       hmax = hmax,
                       control = list(maxit = 10000,
                                      reltol = 1e-32,
                                      trace = 1,
                                      REPORT = 1))
  }else{
    H.res <- optimHess(par = psi,
                       fn = fn,
                       gr = gr,
                       Y = Y,
                       G = G,
                       times = times,
                       hmax = hmax,
                       mu = mu,
                       Sigmai = Sigmai,
                       control = list(maxit = 10000,
                                      reltol = 1e-32,
                                      trace = 1,
                                      REPORT = 1))
  }
  
  if(!isposdef(H.res)){
    H.res <- nearPD(H.res)$mat
  }
  
  gY <- get.gY(psi = psi,
               times = times.pred,
               hmax = hmax,
               Y = Y)
  s2_hat <- get.s2(psi = psi,
                   Y = Y,
                   G = G,
                   times = times,
                   hmax = hmax)
  Hinv <- solve(H.res)*2*s2_hat
  
  vY1 <- apply(gY[[1]], MARGIN = 1, FUN = function(g){
    as.numeric(t(g) %*% Hinv %*% g) + ifelse(mNoise, s2_hat, 0)
  })
  
  vY2 <- apply(gY[[2]], MARGIN = 1, FUN = function(g){
    as.numeric(t(g) %*% Hinv %*% g) + ifelse(mNoise, s2_hat, 0)
  })
  
  
  Y.pred <- get.mu(psi = psi,
                   times = times.pred,
                   hmax = 0.1,
                   Y = Y)
  
  PI_l <- exp(log(Y.pred) - qnorm(1 - alpha/2)*cbind(sqrt(vY1), sqrt(vY2)))
  PI_u <- exp(log(Y.pred) + qnorm(1 - alpha/2)*cbind(sqrt(vY1), sqrt(vY2)))
  
  return(list(PI_l = PI_l,
              PI_u = PI_u,
              m = Y.pred))
}
get.jacF <- function(t, 
                     y, 
                     parms){
  m1 <- y["m1"]
  m2 <- y["m2"]
  
  r <- parms["r"]
  d <- parms["d"]
  l21 <- parms["l21"]
  
  Jf <- matrix(data = c(r - d*(2*m1 + m2), -d*m1 + l21,
                        -d*m2, r - d*(m1 + 2*m2) - l21),
               nrow = 2, ncol = 2,
               byrow = TRUE)
  
  return(Jf)
}