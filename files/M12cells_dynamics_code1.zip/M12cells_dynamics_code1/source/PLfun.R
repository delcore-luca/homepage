nl.PL.try <- function(psi,
                      j,
                      psi_j,
                      Y,
                      G,
                      times,
                      hmax){
  
  psi_full <- rep(NA, length(psi) + 1)
  psi_full[j] <- psi_j
  psi_full[-j] <- psi
  
  nl.res <- try(quiet(get.nl(psi = psi_full,
                             Y = Y,
                             G = G,
                             times = times,
                             hmax = hmax)), silent = TRUE)
  if(inherits(nl.res,'try-error') |
     is.nan(nl.res) |
     is.infinite(nl.res) |
     is.na(nl.res)){
    return(1e8)
  }
  return(nl.res)
}

gnl.PL.try <- function(psi,
                       j,
                       psi_j,
                       Y,
                       G,
                       times,
                       hmax){
  
  
  psi_full <- rep(NA, length(psi) + 1)
  psi_full[j] <- psi_j
  psi_full[-j] <- psi
  
  gnl.res <- try(quiet(get.gnl(psi = psi_full,
                               Y = Y,
                               G = G,
                               times = times,
                               hmax = hmax)[-j]), silent = TRUE)
  
  if(inherits(gnl.res,'try-error') |
     sum(is.nan(gnl.res)) > 0 |
     sum(is.infinite(gnl.res)) > 0 |
     sum(is.na(gnl.res)) > 0){
    return(rep(1e8, length(psi)))
  }
  return(gnl.res)
}


get.PL <- function(psi_MLE,
                   f_MLE,
                   s2_hat,
                   fn,
                   gr = NULL,
                   ...,
                   method = c("optim", "cmaes"),
                   optim.control = list(maxit = 10000,
                                        reltol = 1e-32,
                                        trace = 0,
                                        REPORT = 10),
                   cmaes.control = list(verbose = FALSE,
                                        maxIT = 1000,
                                        maxTime = 3,
                                        xtol = 1e-8,
                                        ftol = 1e-8,
                                        REPORT = 10,
                                        local = FALSE),
                   cmaes.init = NULL,
                   maxIT = 1000,
                   Delta = 0.01,
                   tol = 1e-6,
                   SILENT = TRUE){

  method <- match.arg(method)

  dots <- list(...)
  j <- dots[["j"]]

  thr <- f_MLE + s2_hat * qchisq(0.95, 1)

  ## adaptive tuning
  Delta_min <- 1e-8
  Delta_max <- 1
  target_dPL <- 0.05 * (thr - f_MLE)

  ###########################################################
  ## OPTIMIZER WRAPPER
  ###########################################################

  opt_fun <- function(par, psi_j, ...) {

    if(method == "optim") {

      res <- optim(
        par = par,
        fn = fn,
        gr = gr,
        method = "BFGS",
        control = optim.control,
        psi_j = psi_j,
        ...
      )

      return(list(
        par = res$par,
        value = res$value
      ))
    }

    if(method == "cmaes") {

      init <- cmaes.init

      if(is.null(init)) {
        init <- list(
          N = length(par),
          xmean = par,
          sigma = 1e-2 # 1e-3
        )
      } else {

        ## keep xmean synchronized with current profile point
        init$xmean <- par

        if(is.null(init$N))
          init$N <- length(par)

        if(is.null(init$sigma))
          init$sigma <- 1e-2 # 1e-3
      }

      res <- cmaes(
        par = par,
        fun = fn,
        grad = gr,
        control = cmaes.control,
        cmaes.init = init,
        psi_j = psi_j,
        ...
      )

      return(list(
        par = res$x,
        value = res$f
      ))
    }
  }

  ###########################################################
  ## RIGHT SIDE
  ###########################################################

  PLj_1 <- f_MLE
  psi_j <- psi_MLE[j]
  psij_seq1 <- NULL
  psi.c <- psi_MLE[-j]
  nIT <- 0

  Delta_curr <- Delta
  PLj_curr <- f_MLE

  repeat {

    if(nIT > maxIT)
      break

    PL_prev <- tail(PLj_1, 1)

    psi_try <- psi_j + Delta_curr

    args <- c(
      dots,
      list(
        par = psi.c,
        psi_j = psi_try
      )
    )

    res.PL <- try(
      do.call(opt_fun, args),
      silent = SILENT
    )

    if(inherits(res.PL, "try-error")) {

      Delta_curr <- max(Delta_curr / 2, Delta_min)
      next
    }

    PL_try <- res.PL$value

    cat(
      paste0(
        "\trPL nIt: ", nIT,
        "\trPL value: ", PL_try,
        "\tDelta: ", Delta_curr, "\n"
      )
    )

    ## overshoot handling
    if(PL_try > thr) {

      if(abs(PL_try - thr) < tol) {

        psi_j <- psi_try
        PLj_curr <- PL_try

        psij_seq1 <- c(psij_seq1, psi_j)
        PLj_1 <- c(PLj_1, PLj_curr)

        break
      }

      Delta_curr <- max(Delta_curr / 2, Delta_min)
      next
    }

    ## accept step
    psi_j <- psi_try
    PLj_curr <- PL_try

    psij_seq1 <- c(psij_seq1, psi_j)
    PLj_1 <- c(PLj_1, PLj_curr)

    psi.c <- res.PL$par

    ## adaptive Delta update
    dPL <- PLj_curr - PL_prev

    if(is.finite(dPL) && dPL > 0) {

      fac <- sqrt(target_dPL / dPL)

      fac <- min(max(fac, 0.5), 2)

      Delta_curr <- Delta_curr * fac

      Delta_curr <- min(
        max(Delta_curr, Delta_min),
        Delta_max
      )
    }

    if(abs(PLj_curr - thr) < tol)
      break

    nIT <- nIT + 1
  }

  ###########################################################
  ## LEFT SIDE
  ###########################################################

  PLj_2 <- f_MLE
  psi_j <- psi_MLE[j]
  psij_seq2 <- NULL
  psi.c <- psi_MLE[-j]
  nIT <- 0

  Delta_curr <- Delta
  PLj_curr <- f_MLE

  repeat {

    if(nIT > maxIT)
      break

    PL_prev <- tail(PLj_2, 1)

    psi_try <- psi_j - Delta_curr

    args <- c(
      dots,
      list(
        par = psi.c,
        psi_j = psi_try
      )
    )

    res.PL <- try(
      do.call(opt_fun, args),
      silent = SILENT
    )

    if(inherits(res.PL, "try-error")) {

      Delta_curr <- max(Delta_curr / 2, Delta_min)
      next
    }

    PL_try <- res.PL$value

    cat(
      paste0(
        "\tlPL nIt: ", nIT,
        "\tlPL value: ", PL_try,
        "\tDelta: ", Delta_curr, "\n"
      )
    )

    ## overshoot handling
    if(PL_try > thr) {

      if(abs(PL_try - thr) < tol) {

        psi_j <- psi_try
        PLj_curr <- PL_try

        psij_seq2 <- c(psij_seq2, psi_j)
        PLj_2 <- c(PLj_2, PLj_curr)

        break
      }

      Delta_curr <- max(Delta_curr / 2, Delta_min)
      next
    }

    ## accept step
    psi_j <- psi_try
    PLj_curr <- PL_try

    psij_seq2 <- c(psij_seq2, psi_j)
    PLj_2 <- c(PLj_2, PLj_curr)

    psi.c <- res.PL$par

    ## adaptive Delta update
    dPL <- PLj_curr - PL_prev

    if(is.finite(dPL) && dPL > 0) {

      fac <- sqrt(target_dPL / dPL)

      fac <- min(max(fac, 0.5), 2)

      Delta_curr <- Delta_curr * fac

      Delta_curr <- min(
        max(Delta_curr, Delta_min),
        Delta_max
      )
    }

    if(abs(PLj_curr - thr) < tol)
      break

    nIT <- nIT + 1
  }

  ###########################################################
  ## OUTPUT
  ###########################################################

  PLj <- c(rev(PLj_2[-1]), PLj_1[-1])

  PL_curve <- cbind(
    x = c(rev(psij_seq2), psi_MLE[j], psij_seq1),
    y = c(rev(PLj_2[-1]), f_MLE, PLj_1[-1])
  )

  idx <- which(abs(PLj - thr) < tol)

  PL_IC <- if(length(idx) > 0) {
    unique(
      c(rev(psij_seq2), psij_seq1)[range(idx)]
    )
  } else {
    numeric(0)
  }

  res <- list(
    thr = thr,
    PL_curve = PL_curve,
    PL_IC = PL_IC
  )

  return(res)
}
