cmaes <- function(par,
                  fun,
                  grad = NULL,
                  ...,
                  control = list(verbose = TRUE,
                                 maxIT = 10000,
                                 maxTime = 3, # in hours
                                 xtol = 1e-8,
                                 ftol = 1e-8,
                                 REPORT = 10,
                                 local = FALSE),
                  cmaes.init = list(N = length(par),
                                    xmean = par,
                                    sigma = .001)){
  
  # fun <- deparse(substitute(fun))
  
  # #   --------------------  Initialization --------------------------------  
  N <- cmaes.init$N
  xmean <- cmaes.init$xmean
  sigma <- cmaes.init$sigma
  
  
  #   Strategy parameter setting: Selection  
  lambda = (4+floor(3*log(N)))*1          # population size, offspring number
  mu = lambda/2;                      # number of parents/points for recombination
  weights = log(mu+1/2)-log(1:mu)     # muXone array for weighted recombination
  mu = floor(mu)       
  weights = weights/sum(weights)      # normalize recombination weights array
  mueff=sum(weights)^2/sum(weights^2) # variance-effectiveness of sum w_i x_i
  
  #   Strategy parameter setting: Adaptation
  cc = (4+mueff/N) / (N+4 + 2*mueff/N) # time constant for cumulation for C
  cs = (mueff+2) / (N+mueff+5)         # t-const for cumulation for sigma control
  c1 = 2 / ((N+1.3)^2+mueff);          # learning rate for rank-one update of C
  cmu = min(1-c1, 2 * (mueff-2+1/mueff) / ((N+2)^2+mueff))  # and for rank-mu update
  damps = 1 + 2*max(0, sqrt((mueff-1)/(N+1))-1) + cs; # damping for sigma, usually close to 1
  
  #   Initialize dynamic (internal) strategy parameters and constants
  pc <- matrix(0, N, 1)
  ps <- matrix(0, N, 1)                   # evolution paths for C and sigma
  B <- diag(1, N, N)                      # B defines the coordinate system
  # D <- diag(1, N)                    # diagonal D defines the scaling
  # C = B %*% diag(diag(D))^2 %*% t(B)            # covariance matrix C
  # invsqrtC = B %*% (diag(diag(D)^-1)) %*% t(B)    # C^-1/2 
  D <- rep(1, N)                    # diagonal D defines the scaling
  C = B %*% diag(D^2) %*% t(B)            # covariance matrix C
  invsqrtC = B %*% diag(D^-1) %*% t(B)    # C^-1/2 
  eigeneval = 0                           # track update of B and D
  chiN = N^0.5*(1-1/(4*N)+1/(21*N^2))     # expectation of ||N(0,I)|| == norm(randn(N,1)) 
  
  #   -------------------- Generation Loop --------------------------------
  
  arx <- matrix(NA, N, lambda)
  rownames(arx) <- names(par)
  arfitness <- rep(NA, lambda)
  xall <- matrix(NA, control$maxIT, N)
  fall <- rep(NA, control$maxIT)
  
  f.curr <-  do.call(what = fun,
                     args = list(xmean,
                                 ...))

  f.best <- f.curr
  x.best <- xmean
  
  err.x <- 100
  err.f <- 100
  
  nIT <- 1
  runTime <- 0
  while ((err.x > control$xtol | 
          err.f > control$ftol) & nIT <= control$maxIT 
         & runTime <= (control$maxTime)*60^2) {
    
    stepTime.start <- proc.time()[3]

    if(control$verbose & nIT %% control$REPORT == 0){
      cat(paste0("iter ", nIT,
                 "\tvalue ", f.curr,
                 "\terr.x ", err.x,
                 "\terr.f ", err.f,
                 "\tsigma ", sigma,
                 "\tmin. elapsed ", round(runTime/60, 3),
                 "\n"
      ))
    }
    
    # Generate and evaluate lambda offspring
    counteval <- 0
    for (k in 1:lambda) {
      arx[,k] <- xmean + sigma * B %*% (D * rnorm(N,0,1))       # m + sig * Normal(0,C) 
      arfitness[k] <- do.call(what = fun,
                              args = list(arx[,k],
                                          ...)) # objective function call

      counteval = counteval + 1
    }
    
    # Sort by fitness and compute weighted mean into xmean
    arindex <- order(arfitness)
    arfitness <- sort(arfitness)
    xold <- xmean
    xmean <- (arx[, arindex[1:mu]]%*%weights)[,1]   # recombination, new mean value
    xall[nIT,] <- xmean
    
    f.old <- f.curr
    f.curr <-  do.call(what = fun,
                       args = list(xmean,
                                   ...))

    fall[nIT] <- f.curr
    
    err.x <- norm(xmean - x.best, "2")/norm(x.best, "2")
    err.f <- norm(f.curr - f.best, "2")/norm(f.best, "2")
    if(f.curr < f.best){
      f.best <- f.curr
      x.best <- xmean
    }

    # Cumulation: Update evolution paths
    ps = ((1-cs)*ps + sqrt(cs*(2-cs)*mueff) * invsqrtC %*% (xmean-xold) / sigma)
    hsig = norm(ps, type = "2")/sqrt(1-(1-cs)^(2*counteval/lambda))/chiN < 1.4 + 2/(N+1)
    pc = ((1-cc)*pc + hsig * sqrt(cc*(2-cc)*mueff) * (xmean-xold) / sigma)
    
    # Adapt covariance matrix C
    artmp = (1/sigma) * (arx[,arindex[1:mu]] - replicate(mu, xold))
    C = ((1-c1-cmu) * C                   # regard old matrix  
         + c1 * (pc%*%t(pc)                  # plus rank one update
                 + (1-hsig) * cc*(2-cc) * C)  # minor correction if hsig==0
         + cmu * artmp %*% diag(weights) %*% t(artmp)) # plus rank mu update
    
    # Adapt step size sigma
    # sigma = sigma * exp((cs/damps)*(norm(ps, type = "2")/chiN - 1))
    sigma = sigma * exp(min(1, (cs/damps)*(norm(ps, type = "2")/chiN - 1)))
    
    # Decomposition of C into B*diag(D.^2)*B' (diagonalization)
    C <- (C + t(C))/2 # enforce symmetry
    
    #########
    if(sum(is.na(C)) > 0 |
       sum(is.nan(C)) > 0 |
       sum(is.infinite(C)) > 0){
      C = B %*% diag(D^2) %*% t(B)            # covariance matrix C
    }

    BD <- try(quiet(eigen(C)), silent = TRUE)
    if(inherits(BD,'try-error')){
      runTime <- Inf
    }else{
      D <- BD$values
      B <- BD$vectors
      D = sqrt(D)
      invsqrtC = B %*% (diag(D^-1)) %*% t(B)

      nIT <- nIT + 1
      
      stepTime.end <- proc.time()[3]
      stepTime <- stepTime.end - stepTime.start
      
      runTime <- runTime + stepTime
    }
    
    
  }
  
  res <- list()
  res$x <- xmean
  res$f <- f.curr
  res$xall <- head(xall, nIT)
  res$fall <- head(fall, nIT)
  
  res$x.best <- xall[order(fall[1:(nIT - 1)])[1],]
  res$f.best <- min(fall, na.rm = TRUE)
  
  ## CMAES parameters
  res$C <- C
  res$invsqrtC <- invsqrtC
  res$xmean <- xmean
  res$sigma <- sigma
  
  
  return(res)
}