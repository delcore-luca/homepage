nl.try <- function(psi,
                   Y,
                   G,
                   times,
                   hmax){
  nl.res <- try(quiet(get.nl(psi = psi,
                             Y = Y,
                             G = G,
                             times = times,
                             hmax = hmax)), silent = TRUE)
  if(inherits(nl.res,'try-error') |
     is.nan(nl.res) |
     is.infinite(nl.res) |
     is.na(nl.res)){
    return(1e8)
  }
  return(nl.res)
}

gnl.try <- function(psi,
                    Y,
                    G,
                    times,
                    hmax){
  gnl.res <- try(quiet(get.gnl(psi = psi,
                               Y = Y,
                               G = G,
                               times = times,
                               hmax = hmax)), silent = TRUE)
  
  if(inherits(gnl.res,'try-error') |
     sum(is.nan(gnl.res)) > 0 |
     sum(is.infinite(gnl.res)) > 0 |
     sum(is.na(gnl.res)) > 0){
    return(rep(1e8, length(psi)))
  }
  return(gnl.res)
}

# ## Fisher Information based prediction intervals
get.FIM.PI <- function(psi,
                       times,
                       times.pred,
                       hmax,
                       Y,
                       G,
                       fn,
                       gr,
                       mu = NULL,
                       Sigmai = NULL,
                       alpha,
                       mNoise = FALSE){
  
  if(is.null(mu) & is.null(Sigmai)){
    H.res <- optimHess(par = psi,
                       fn = fn,
                       gr = gr,
                       Y = Y,
                       G = G,
                       times = times,
                       hmax = hmax,
                       control = list(maxit = 10000,
                                      reltol = 1e-32,
                                      trace = 1,
                                      REPORT = 1))
  }else{
    H.res <- optimHess(par = psi,
                       fn = fn,
                       gr = gr,
                       Y = Y,
                       G = G,
                       times = times,
                       hmax = hmax,
                       mu = mu,
                       Sigmai = Sigmai,
                       control = list(maxit = 10000,
                                      reltol = 1e-32,
                                      trace = 1,
                                      REPORT = 1))
  }
  
  if(!isposdef(H.res)){
    H.res <- nearPD(H.res)$mat
  }
  
  gY <- get.gY(psi = psi,
               times = times.pred,
               hmax = hmax)
  s2_hat <- get.s2(psi = psi,
                   Y = Y,
                   G = G,
                   times = times,
                   hmax = hmax)
  Hinv <- solve(H.res)*2*s2_hat
  
  vY1 <- apply(gY[[1]], MARGIN = 1, FUN = function(g){
    as.numeric(t(g) %*% Hinv %*% g) + ifelse(mNoise, s2_hat, 0)
  })
  
  vY2 <- apply(gY[[2]], MARGIN = 1, FUN = function(g){
    as.numeric(t(g) %*% Hinv %*% g) + ifelse(mNoise, s2_hat, 0)
  })
  
  
  Y.pred <- get.mu(psi = psi,
                   times = times.pred,
                   hmax = 0.1)
  
  PI_l <- exp(log(Y.pred) - qnorm(1 - alpha/2)*cbind(sqrt(vY1), sqrt(vY2)))
  PI_u <- exp(log(Y.pred) + qnorm(1 - alpha/2)*cbind(sqrt(vY1), sqrt(vY2)))
  
  return(list(PI_l = PI_l,
              PI_u = PI_u,
              m = Y.pred))
}

# ## Fisher Information based confidence intervals
## Fisher Information based confidence intervals
get.FIM.CI <- function(psi,
                       times,
                       hmax,
                       Y,
                       G,
                       alpha){
  
  H.res <- optimHess(par = psi,
                     fn = nl.try,
                     gr = gnl.try,
                     Y = Y,
                     G = G,
                     times = times,
                     hmax = hmax,
                     control = list(maxit = 10000,
                                    reltol = 1e-32,
                                    trace = 1,
                                    REPORT = 1))
  
  if(!isposdef(H.res)){
    H.res <- nearPD(H.res)$mat
  }
  
  s2_hat <- get.s2(psi = psi,
                   Y = Y,
                   G = G,
                   times = times,
                   hmax = hmax)
  Hinv <- solve(H.res)*2*s2_hat
  
  FIM_CIs <- cbind(psi - qnorm(1 - alpha/2)*sqrt(diag(Hinv)),
                   psi + qnorm(1 - alpha/2)*sqrt(diag(Hinv)))
  
  return(FIM_CIs)
}

get.logit <- function(x){
  return(log(x/(1-x)))
}

get.BIC <- function(nl,
                    p,
                    N){
  
  return(as.numeric(2*nl + p*log(N)))
}

## Fisher Information based confidence ellipses
get.ellipse <- function(phi,
                        levels = c(.99, .95, .9),
                        fim,
                        s2 = 1,
                        post.samples = NULL){
  
  levels <- sort(levels, decreasing = TRUE)
  
  p <- length(phi)
  cov.phi <- solve(fim)*2*s2
  t <- seq(0, 2*pi, length.out = 100)
  
  par(mar = c(.5,.5,.5,.5), mfrow = c(p,p))
  for (j in (p-1):1) {
    if(j >= 2){
      for (h in 1:(j - 1)) {
        plot.new()
      }
    }
    for (i in (j+1):p) {
      x0 <- phi[i]
      y0 <- phi[j]
      
      eigen_ij <- eigen(cov.phi[c(i,j), c(i,j)])
      max.v <- eigen_ij$vectors[,1]
      alpha <- atan(max.v[2]/max.v[1])
      
      par(mar = c(.5,.5,.5,.5))
      
      for (k in 1:length(levels)) {
        ab <-  sqrt(qchisq(p = levels[k], df = 2) * eigen_ij$values)
        a <- ab[1]
        b <- ab[2]
        xi <- a*cos(t)
        xj <- b*sin(t)
        
        if(!is.null(post.samples)){
          kde <- kde2d(post.samples[,i], post.samples[,j], n = 100)
          dens_vals <- as.vector(kde$z)
          ord <- order(dens_vals, decreasing = TRUE)
          cumprob <- cumsum(dens_vals[ord]) / sum(dens_vals)
          threshold <- dens_vals[ord][which(cumprob >= levels[k])[1]]
        }
        
        if(k == 1){
          if(!is.null(post.samples)){
            contour(kde,
                    levels = threshold, 
                    drawlabels = FALSE,
                    add = TRUE,
                    col = "cyan",
                    lwd = 2)
            
            plot(post.samples[,c(i,j)],
                 type = 'p', 
                 # lwd = 2,
                 cex.axis = 1,
                 cex.lab = 2,
                 bty = 'n',
                 yaxt = 'n',
                 xaxt = ifelse(j == 1, "s", "n"),
                 xlab = bquote(log~theta[.(i)]),
                 ylab = bquote(log~theta[.(j)]))
            lines(xi*cos(alpha) - xj*sin(alpha) + x0,
                  xi*sin(alpha) + xj*cos(alpha) + y0,
                  lwd = 2,
                  col = "red")
          }else{
            plot(xi*cos(alpha) - xj*sin(alpha) + x0,
                 xi*sin(alpha) + xj*cos(alpha) + y0, 
                 type = 'l', 
                 lwd = 2,
                 cex.axis = 1,
                 cex.lab = 2,
                 bty = 'n',
                 yaxt = 'n',
                 xaxt = ifelse(j == 1, "s", "n"),
                 xlab = bquote(log~theta[.(i)]),
                 ylab = bquote(log~theta[.(j)]))
          }
          
          max.range.xi <- xi*cos(alpha) - xj*sin(alpha) + x0
          max.range.xj <- xi*sin(alpha) + xj*cos(alpha) + y0
          if(i == p){
            axis(side = 4)
            mtext(bquote(log~theta[.(j)]), 
                  side=4, 
                  line=3,
                  cex = 1.5)
          }
          if(j == 1){
            axis(side = 1)
            mtext(bquote(log~theta[.(i)]), 
                  side=1, 
                  line=3,
                  cex = 1.5)
          }
        }else{
          lines(xi*cos(alpha) - xj*sin(alpha) + x0,
                xi*sin(alpha) + xj*cos(alpha) + y0,
                lwd = 2,
                col = ifelse(!is.null(post.samples), "red", "black"))
          
          if(!is.null(post.samples)){
            contour(kde,
                    levels = threshold, 
                    drawlabels = FALSE,
                    add = TRUE,
                    col = "cyan",
                    lwd = 2)
          }
          
        }
      }
      points(x0, y0, 
             pch = "*", 
             cex = 3, 
             col = ifelse(!is.null(post.samples), "red", "black"))
      
    }
    par(mar = c(.1,.1,.1,.1))
    plot.new()
    
  }
  
}
