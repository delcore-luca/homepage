
get.nl <- function(psi,
                   Y,
                   G,
                   times,
                   hmax = .01){
  
  r <- exp(psi[1])
  d <- exp(psi[2])
  l21 <- exp(psi[3])
  m1 <- exp(psi[4])
  m2 <- exp(psi[4])
  
  
  J <- dim(Y)[3]
  
  X <- try(vode(y = c(m1 = m1,
                      m2 = m2),
                times = times,
                func = get.dx,
                parms = c(r = r,
                          d = d,
                          l21 = l21),
                mf = -21, # -21
                jacfunc = get.jacF,
                hmax = hmax)[,-1], silent = TRUE)
  
  X[X < 0] <- 1e-8
  
  X <- replicate(J, X)
  X <- X[G]
  Y <- Y[G]
  
  H <- log(X)
  nl <- as.numeric(-2*t(H)%*%Y + t(H)%*%H)
  
  return(nl)
}

get.s2 <- function(psi,
                   Y,
                   G,
                   times,
                   hmax = .01){
  
  r <- exp(psi[1])
  d <- exp(psi[2])
  l21 <- exp(psi[3])
  m1 <- exp(psi[4])
  m2 <- exp(psi[4])
  
  
  J <- dim(Y)[3]
  
  X <- try(vode(y = c(m1 = m1,
                      m2 = m2),
                times = times,
                func = get.dx,
                parms = c(r = r,
                          d = d,
                          l21 = l21),
                mf = -21, # -21
                jacfunc = get.jacF,
                hmax = hmax)[,-1], silent = TRUE)
  
  X[X < 0] <- 1e-8
  
  X <- replicate(J, X)
  X <- X[G]
  Y <- Y[G]
  
  H <- log(X)
  # s2_hat <- as.numeric(t(Y - H) %*% (Y - H))/length(Y)
  s2_hat <- as.numeric(t(Y - H) %*% (Y - H))/(length(Y) - length(psi))
  
  return(s2_hat)
}


get.mu <- function(psi,
                   times,
                   hmax = .01){
  
  r <- exp(psi[1])
  d <- exp(psi[2])
  l21 <- exp(psi[3])
  m1 <- exp(psi[4])
  m2 <- exp(psi[4])
  
  X <- try(vode(y = c(m1 = m1,
                      m2 = m2),
                times = times,
                func = get.dx,
                parms = c(r = r,
                          d = d,
                          l21 = l21),
                mf = -21, # -21
                jacfunc = get.jacF,
                hmax = hmax)[,-1], silent = TRUE)
  
  return(X)
}

get.gnl <- function(psi,
                    Y,
                    G,
                    times,
                    hmax = .01){
  
  r <- exp(psi[1])
  d <- exp(psi[2])
  l21 <- exp(psi[3])
  m1 <- exp(psi[4])
  m2 <- exp(psi[4])
  
  np <- length(psi)
  nx <- 2
  
  J <- dim(Y)[3] # n. of clones
  
  XS <- try(vode(y = c(m1 = m1,
                       m2 = m2,
                       s11 = 0,
                       s12 = 0,
                       s21 = 0,
                       s22 = 0,
                       s31 = 0,
                       s32 = 0,
                       s41 = 1,
                       s42 = 1),
                 times = times,
                 func = get.dx.ws,
                 parms = c(r = r,
                           d = d,
                           l21 = l21),
                 # mf = -21, # -21
                 # jacfunc = get.jacF,
                 hmax = hmax)[,-1], silent = TRUE)
  
  X <- XS[,1:2]
  S <- XS[,-c(1,2)]
  
  X[X < 0] <- 1e-8
  
  X <- replicate(J, X)
  
  X <- X[G]
  Y <- Y[G]
  
  S <- S[,c(t(matrix(data = 1:(np*nx), ncol = nx, byrow = TRUE)[rep(1:np, each = J),]))]
  S <- matrix(data = S[matrix(data = c(G), nrow = length(times), ncol = np*nx*J)], ncol = np)
  
  H <- log(X)
  dH <- 1/X*S
  gnl <- as.numeric(-2*t(dH)%*%Y + 2*t(dH)%*%H)*exp(psi)
  
  return(gnl)
}

get.gY <- function(psi,
                   times,
                   hmax = .01){
  
  r <- exp(psi[1])
  d <- exp(psi[2])
  l21 <- exp(psi[3])
  m1 <- exp(psi[4])
  m2 <- exp(psi[4])
  
  np <- length(psi)
  nx <- 2
  
  XS <- try(vode(y = c(m1 = m1,
                       m2 = m2,
                       s11 = 0,
                       s12 = 0,
                       s21 = 0,
                       s22 = 0,
                       s31 = 0,
                       s32 = 0,
                       s41 = 1,
                       s42 = 1),
                 times = times,
                 func = get.dx.ws,
                 parms = c(r = r,
                           d = d,
                           l21 = l21),
                 # mf = -21, # -21
                 # jacfunc = get.jacF,
                 hmax = hmax)[,-1], silent = TRUE)
  
  X <- XS[,1:2]
  S <- XS[,-c(1,2)]
  
  X[X < 0] <- 1e-8
  

  S1 <- S[,rep(c(TRUE,FALSE), times = np)]
  S2 <- S[,rep(c(FALSE,TRUE), times = np)]
  
  # H <- log(X)
  dH1 <- 1/X[,1]*S1
  dH2 <- 1/X[,2]*S2

  gY1 <- dH1*matrix(data = exp(psi),
                    nrow = nrow(dH1),
                    ncol = length(psi),
                    byrow = TRUE)
  
  gY2 <- dH2*matrix(data = exp(psi),
                    nrow = nrow(dH2),
                    ncol = length(psi),
                    byrow = TRUE)
  
  return(list(gY1,
              gY2))
}


get.dx.ws <- function(t,
                      y, 
                      parms){
  m1 <- y["m1"]
  m2 <- y["m2"]
  
  np <- 4
  
  S <- matrix(y[3:(2 + 2*np)], nrow = 2, ncol = np)
  
  r <- parms["r"]
  d <- parms["d"]
  l21 <- parms["l21"]
  
  f <- c(r*m1 - d*m1*(m1 + m2) + l21*m2,
         r*m2 - d*m2*(m1 + m2) - l21*m2)
  
  # Jacobian
  Jf <- matrix(data = c(r - d*(2*m1 + m2), -d*m1 + l21,
                        -d*m2, r - d*(m1 + 2*m2) - l21),
               nrow = 2, ncol = 2,
               byrow = TRUE)
  
  # df/dtheta
  df_dtheta <- matrix(data = c(m1, m2, # r
                               -m1*(m1 + m2), -m2*(m1 + m2), # d
                               m2, -m2, # l21
                               0,0), # m1(0) / m2(0)
                      nrow = 2)
  
  dS <- Jf %*% S + df_dtheta
  
  return(list(c(f, as.vector(dS))))
}

get.dx <- function(t,
                   y, 
                   parms){
  m1 <- y["m1"]
  m2 <- y["m2"]
  
  r <- parms["r"]
  d <- parms["d"]
  l21 <- parms["l21"]
  
  
  f <- c(r*m1 - d*m1*(m1 + m2) + l21*m2,
         r*m2 - d*m2*(m1 + m2) - l21*m2)
  
  return(list(f))
}

get.jacF <- function(t, 
                     y, 
                     parms){
  m1 <- y["m1"]
  m2 <- y["m2"]
  
  r <- parms["r"]
  d <- parms["d"]
  l21 <- parms["l21"]
  
  Jf <- matrix(data = c(r - d*(2*m1 + m2), -d*m1 + l21,
                        -d*m2, r - d*(m1 + 2*m2) - l21),
               nrow = 2, ncol = 2,
               byrow = TRUE)
  
  return(Jf)
}